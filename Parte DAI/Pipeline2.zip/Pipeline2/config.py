import os

import psycopg2

# ---------------------------------------------------------------------------
# DESTINAZIONE: il database PostgreSQL unico in cui confluiscono i dati puliti
# Le credenziali NON sono nel codice: impostare la variabile d'ambiente
# DATABASE_URL, es.  postgresql://utente:password@host:5432/buby_travel
# (il database deve già esistere; schema e tabelle vengono creati dalla pipeline).
# ---------------------------------------------------------------------------
DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://<username>:<password>@localhost:5432/buby_travel",
)
DB_SCHEMA = os.getenv("DB_SCHEMA", "buby_travel_dw")


def get_connection(autocommit: bool = False):
    check_url(DATABASE_URL, "DATABASE_URL")
    conn = psycopg2.connect(DATABASE_URL)
    conn.autocommit = autocommit
    return conn


# ---------------------------------------------------------------------------
# SORGENTI: 6 database, uno per struttura. Ogni database contiene i dati della
# propria struttura (anagrafica, camere, listino, prenotazioni, occupazione,
# recensioni) e una copia delle tabelle condivise della catena (canali,
# stagionalità, eventi, promozioni). La pipeline li legge tutti, li unisce,
# li pulisce e li carica nel database di destinazione.
#
# Per ogni fonte:
#   nome          etichetta della fonte (finisce nella colonna "fonte" di ogni record)
#   id_struttura  struttura a cui appartiene il database (controllo di coerenza)
#   url           connessione (variabile d'ambiente dedicata). PostgreSQL via psycopg2;
#                 altri motori (MySQL, SQL Server...) via SQLAlchemy, es. mysql+pymysql://...
#   schema        schema da cui leggere
#   tabelle       (facoltativo) nome diverso della tabella o query SELECT completa;
#                 None = tabella non presente in quella fonte
#   colonne       (facoltativo) rinomina delle colonne specifiche di quella fonte
# ---------------------------------------------------------------------------
def same_server_url(dbname: str) -> str:
    """Stesso server e credenziali di DATABASE_URL, ma un altro database."""
    return DATABASE_URL.rsplit("/", 1)[0] + "/" + dbname


def check_url(url: str, var: str, db: str = "buby_travel"):
    if "<username>" in url or "<password>" in url:
        raise RuntimeError(
            f"Credenziali PostgreSQL non impostate. In PowerShell esegui prima:\n"
            f'  $env:{var}="postgresql://postgres:LA_TUA_PASSWORD@localhost:5432/{db}"\n'
            f"(nella stessa finestra da cui lanci lo script).")


def _src(nome, id_struttura, db, **extra):
    # Se DB_URL_S0x non è impostata, si usa lo stesso server/credenziali di DATABASE_URL
    # (comodo per i database demo, tutti sullo stesso PostgreSQL locale)
    env = f"DB_URL_{id_struttura}"
    return {"nome": nome, "id_struttura": id_struttura, "schema": extra.pop("schema", "public"),
            "url": os.getenv(env) or same_server_url(db),
            "url_env": env, "tabelle": extra.pop("tabelle", {}), "colonne": extra.pop("colonne", {})}


SOURCE_DATABASES = [
    _src("db_riva_del_lago",      "S01", "hotel_riva_del_lago"),
    _src("db_belvedere",          "S02", "hotel_belvedere"),
    _src("db_le_palme",           "S03", "residence_le_palme"),
    _src("db_cime_bianche",       "S04", "hotel_cime_bianche"),
    _src("db_chalet_alpino",      "S05", "chalet_alpino"),
    _src("db_monte_rosa",         "S06", "hotel_monte_rosa"),
    # Esempio di fonte con schema diverso (nomi di tabelle/colonne propri del suo gestionale):
    # _src("db_monte_rosa", "S06", "hotel_monte_rosa",
    #      tabelle={"prenotazioni": "bookings", "recensioni": None},
    #      colonne={"prenotazioni": {"booking_code": "id_prenotazione", "arrival": "check_in"}}),
]

# Nome predefinito della tabella in ogni database sorgente (tabella logica -> tabella fisica)
SOURCE_TABLES = {
    "strutture": "struttura", "camere": "camere", "canali": "canali", "stagionalita": "stagionalita",
    "eventi": "eventi", "listino": "listino", "promozioni": "promozioni", "prenotazioni": "prenotazioni",
    "occupazione": "occupazione_giornaliera", "recensioni": "recensioni",
}
# Tabelle condivise dalla catena: ogni fonte ne ha una copia -> si tiene una sola versione
SHARED_TABLES = ["canali", "stagionalita", "eventi", "promozioni"]
# Tabelle della singola struttura: si uniscono (UNION) e ogni record viene marcato con la fonte
LOCAL_TABLES = ["strutture", "camere", "listino", "prenotazioni", "occupazione", "recensioni"]

# Se una fonte non risponde o manca una tabella obbligatoria:
#   "skip" -> la fonte viene saltata, le altre si caricano, l'esecuzione risulta PARTIAL
#   "fail" -> la pipeline si ferma
SOURCE_ERROR_POLICY = os.getenv("SOURCE_ERROR_POLICY", "skip")
MIN_SOURCES_OK = int(os.getenv("MIN_SOURCES_OK", "1"))   # sotto questa soglia la pipeline si ferma

# Gli id delle prenotazioni/recensioni sono univoci solo dentro il proprio database:
# nel database unico si prefissano con la struttura (BT24-00001 -> S01-BT24-00001).
# L'id originale resta nelle colonne *_origine.
PREFIX_IDS = {"prenotazioni": ["id_prenotazione"], "recensioni": ["id_recensione", "id_prenotazione"]}
ORIGIN_ID_COLUMNS = {"prenotazioni": {"id_prenotazione": "id_prenotazione_origine"},
                     "recensioni": {"id_recensione": "id_recensione_origine"}}

# Tabelle facoltative: se una fonte non le ha, per quella fonte restano vuote
OPTIONAL_SOURCES = ["recensioni"]
# Colonne indispensabili: se mancano in una fonte, quella fonte viene segnalata con un messaggio chiaro
REQUIRED_COLUMNS = {"recensioni": ["id_recensione", "id_prenotazione", "data_recensione"]}
# Colonne attese (quelle assenti non indispensabili vengono create vuote)
EXPECTED_COLUMNS = {
    # la struttura può non essere scritta nei record: si ricava dal database di provenienza
    "strutture": ["id_struttura"], "camere": ["id_struttura"], "listino": ["id_struttura", "nome_struttura"],
    "prenotazioni": ["nome_struttura"], "occupazione": ["nome_struttura"],
    "recensioni": ["id_recensione", "id_prenotazione", "data_recensione", "voto", "piattaforma", "titolo", "testo"],
}

# Rinomina colonne in fase di estrazione: nomi omogenei fra le tabelle
# (tutte le date di validità -> data_inizio/data_fine, importi con suffisso _eur).
RENAME = {
    "stagionalita": {"dal": "data_inizio", "al": "data_fine"},
    "eventi": {"dal": "data_inizio", "al": "data_fine"},
    "listino": {
        "struttura": "nome_struttura", "valido_dal": "data_inizio", "valido_al": "data_fine",
        "tariffa_notte_camera_bb": "tariffa_notte_bb_eur",
        "suppl_mezza_pensione_a_persona": "suppl_mezza_pensione_eur",
        "suppl_pensione_completa_a_persona": "suppl_pensione_completa_eur",
    },
    "prenotazioni": {
        "struttura": "nome_struttura", "tipologia_camera": "tipologia",
        "trattamento": "codice_trattamento", "paese": "codice_paese",
        "importo_totale": "importo_totale_eur",
    },
    "occupazione": {"struttura": "nome_struttura", "ricavo_camere": "ricavo_camere_eur"},
    # nomi alternativi accettati per le colonne delle recensioni
    "recensioni": {"data": "data_recensione", "rating": "voto", "punteggio": "voto", "valutazione": "voto",
                   "fonte": "piattaforma", "canale": "piattaforma", "commento": "testo", "recensione": "testo",
                   "review_text": "testo", "testo_recensione": "testo", "text": "testo",
                   "id_booking": "id_prenotazione", "booking_id": "id_prenotazione", "id_reservation": "id_prenotazione",
                   "reservation_id": "id_prenotazione", "codice_prenotazione": "id_prenotazione",
                   "prenotazione": "id_prenotazione", "id_pren": "id_prenotazione", "cod_prenotazione": "id_prenotazione",
                   "numero_prenotazione": "id_prenotazione",
                   "id_review": "id_recensione", "review_id": "id_recensione", "codice_recensione": "id_recensione",
                   "id": "id_recensione", "review_date": "data_recensione", "data_review": "data_recensione",
                   "score": "voto", "stelle": "voto", "platform": "piattaforma", "sito": "piattaforma",
                   "title": "titolo"},
}

# Chiave naturale usata nei log/quarantena per riconoscere il record
NATURAL_KEY = {
    "strutture": ["id_struttura"], "camere": ["id_struttura", "tipologia"], "canali": ["canale"],
    "stagionalita": ["area", "data_inizio"], "eventi": ["evento", "data_inizio"],
    "listino": ["id_struttura", "tipologia", "data_inizio"], "promozioni": ["codice_promo"],
    "prenotazioni": ["id_prenotazione"], "occupazione": ["data"],
    "recensioni": ["id_recensione"],
}

# ---------------------------------------------------------------------------
# Parametri generali
# ---------------------------------------------------------------------------
# Oltre questa quota di scarti la pipeline si ferma (file probabilmente corrotto)
MAX_REJECT_RATIO = {"default": 0.05, "prenotazioni": 0.08, "occupazione": 0.05}

# "NA" escluso di proposito: è il codice ISO della Namibia
NA_VALUES = ["", "NULL", "null", "NaN", "nan", "None", "none", "N/A", "n/a", "-", "--"]

FUZZY_CUTOFF = 0.85   # tolleranza correzione refusi (difflib)
IQR_K = 3.0           # k=3 -> solo outlier "estremi"

# ---------------------------------------------------------------------------
# Formati: colonne per tipo (nomi DOPO il RENAME)
#   date    -> DATE ISO (YYYY-MM-DD)
#   importi -> NUMERIC(10,2) in euro, separatore decimale punto
#   pct     -> NUMERIC(5,2) da 0 a 100
#   interi  -> SMALLINT/INTEGER
# ---------------------------------------------------------------------------
DATE_FORMATS = ["%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%d/%m/%Y", "%d-%m-%y", "%d-%m-%Y", "%d.%m.%Y", "%Y/%m/%d"]
STANDARD_DATE_FORMATS = 2   # i primi N formati sono "standard" (ISO/Excel): gli altri vengono segnalati

DATE_COLUMNS = {
    "stagionalita": ["data_inizio", "data_fine"],
    "eventi": ["data_inizio", "data_fine"],
    "listino": ["data_inizio", "data_fine"],
    "prenotazioni": ["data_prenotazione", "check_in", "check_out", "data_cancellazione"],
    "occupazione": ["data"],
    "recensioni": ["data_recensione"],
}
AMOUNT_COLUMNS = {
    "listino": ["tariffa_notte_bb_eur", "suppl_mezza_pensione_eur", "suppl_pensione_completa_eur"],
    "prenotazioni": ["importo_totale_eur"],
    "occupazione": ["ricavo_camere_eur"],
}
PCT_COLUMNS = {"canali": ["commissione_pct"], "promozioni": ["sconto_pct"]}
INT_COLUMNS = {
    "strutture": ["unita_totali"],
    "camere": ["n_unita", "capienza_max"],
    "prenotazioni": ["notti"],
    "occupazione": ["camere_disponibili", "camere_fuori_servizio", "camere_occupate",
                    "arrivi", "partenze", "ospiti_presenti"],
}

# ---------------------------------------------------------------------------
# Valori mancanti: campi critici (se mancano -> quarantena)
# ---------------------------------------------------------------------------
CRITICAL_COLUMNS = {
    "strutture": ["id_struttura", "nome", "localita", "area", "categoria", "unita_totali", "periodi_apertura"],
    "camere": ["id_struttura", "tipologia", "n_unita", "capienza_max"],
    "canali": ["canale", "tipo", "commissione_pct"],
    "stagionalita": ["area", "stagione", "data_inizio", "data_fine"],
    "eventi": ["evento", "area", "data_inizio", "data_fine"],
    "listino": ["id_struttura", "tipologia", "stagione", "data_inizio", "data_fine", "tariffa_notte_bb_eur"],
    "promozioni": ["codice_promo", "descrizione", "sconto_pct", "canali"],
    "prenotazioni": ["id_prenotazione", "data_prenotazione", "check_in", "check_out",
                     "tipologia", "ospiti", "codice_trattamento", "canale", "importo_totale_eur",
                     "stato", "codice_cliente"],
    "occupazione": ["data", "camere_disponibili", "camere_occupate", "ricavo_camere_eur"],
    "recensioni": ["id_recensione", "id_prenotazione", "data_recensione"],
}
# Conteggi dell'occupazione: assenza = 0 (non ci sono stati arrivi/partenze/guasti)
ZERO_FILL_COLUMNS = {"occupazione": ["camere_fuori_servizio", "arrivi", "partenze"]}
PAESE_SCONOSCIUTO = "XX"   # codice ISO riservato per "paese non noto"

# ---------------------------------------------------------------------------
# Domini categorici: valori canonici + alias espliciti
# ---------------------------------------------------------------------------
AREE = ["lago", "montagna"]
TIPI_STRUTTURA = ["Hotel", "Residence"]
STAGIONI = ["chiusura", "bassa", "media", "alta", "altissima"]
PERIODI_STAGIONE = ["inverno", "estate"]

# Nomi struttura scritti in modo diverso nei file operativi -> id_struttura.
# (Le forme "nome completo" e "nome senza Hotel/Residence/Chalet" vengono generate in automatico.)
STRUTTURE_ALIASES = {
    "HRL": "S01", "Hotel Riva Lago": "S01",
    "Hotel Belvedere Stresa": "S02",
    "Res. Le Palme": "S03",
    "Hotel C. Bianche": "S04",
    "Chalet Alpino Limone": "S05", "Alpino": "S05",
    "Hotel M. Rosa": "S06",
}

TIPOLOGIE_ALIASES = {
    "STD": "Standard", "Sup.": "Superior", "Sup": "Superior",
    "Superior lago": "Superior vista lago", "Sup. vista lago": "Superior vista lago",
    "Famiglia": "Family", "Family room": "Family",
    "Mono": "Monolocale", "Bilo": "Bilocale", "Trilo": "Trilocale",
}

TRATTAMENTI = {   # codice -> descrizione
    "RO": "Solo pernottamento", "BB": "Pernottamento e colazione",
    "HB": "Mezza pensione", "FB": "Pensione completa",
}
TRATTAMENTI_ALIASES = {
    "Solo pernottamento": "RO", "SP": "RO",
    "B&B": "BB", "Pernottamento e colazione": "BB",
    "MP": "HB", "Mezza pensione": "HB",
    "PC": "FB", "Pensione completa": "FB",
}

CANALI_ALIASES = {
    "Diretto - sito": "Sito ufficiale", "sito": "Sito ufficiale", "Sito web": "Sito ufficiale",
    "Sito": "Sito ufficiale",
    "Stay Hub": "StayHub", "Travel Nest": "TravelNest",
    "T.O.": "Tour operator", "TO": "Tour operator",
    "Agenzia": "Agenzia viaggi", "AdV": "Agenzia viaggi",
    "Email": "Telefono/Email", "Telefono": "Telefono/Email", "Diretto - tel": "Telefono/Email",
    "Corporate": "Convenzione aziendale", "Azienda": "Convenzione aziendale",
}
PROMO_CANALI_TUTTI = "Tutti"

STATI = ["confermata", "cancellata", "no-show"]
STATI_ALIASES = {"annullata": "cancellata", "noshow": "no-show", "No show": "no-show"}

PAESI = {   # ISO 3166-1 alpha-2 -> nome
    "IT": "Italia", "DE": "Germania", "FR": "Francia", "CH": "Svizzera", "GB": "Regno Unito",
    "NL": "Paesi Bassi", "US": "Stati Uniti", "AT": "Austria", "BE": "Belgio", "ES": "Spagna",
    "SE": "Svezia", "PL": "Polonia", PAESE_SCONOSCIUTO: "Sconosciuto",
}
PAESI_ALIASES = {
    "ITA": "IT", "DEU": "DE", "FRA": "FR", "CHE": "CH", "GBR": "GB", "UK": "GB", "NLD": "NL",
    "USA": "US", "AUT": "AT", "BEL": "BE", "ESP": "ES", "SWE": "SE", "POL": "PL",
    "Olanda": "NL", "Inghilterra": "GB",
}
PAESI_ALIASES.update({nome: cod for cod, nome in PAESI.items() if cod != PAESE_SCONOSCIUTO})

MESI_IT = {m: i for i, m in enumerate(
    ["gennaio", "febbraio", "marzo", "aprile", "maggio", "giugno", "luglio",
     "agosto", "settembre", "ottobre", "novembre", "dicembre"], 1)}

# Recensioni: piattaforme ammesse (i valori sconosciuti diventano "Altro", con flag)
PIATTAFORME = ["Sito ufficiale", "StayHub", "TravelNest", "Google", "Tripadvisor",
               "Questionario post-soggiorno", "Altro", "Non indicata"]
PIATTAFORME_ALIASES = {"Sito": "Sito ufficiale", "Sito web": "Sito ufficiale", "Stay Hub": "StayHub",
                       "Travel Nest": "TravelNest", "Google Maps": "Google", "TripAdvisor": "Tripadvisor",
                       "Questionario": "Questionario post-soggiorno", "Email": "Questionario post-soggiorno",
                       "Survey": "Questionario post-soggiorno"}
# Formato unico del voto: scala 0-10 con un decimale (4/5 -> 8.0, 85% -> 8.5, ★★★☆☆ -> 6.0)
# Un numero senza scala viene interpretato: <=5 su 5, <=10 su 10, <=100 su 100 (flag "scala_voto_dedotta")
GIORNI_MAX_RECENSIONE = 365   # oltre: recensione molto tardiva (flag)

# Età sotto la quale un bambino è considerato neonato (culla, non occupa posto letto)
ETA_NEONATO = 2

# ---------------------------------------------------------------------------
# Limiti fisici/di business: oltre -> errore (quarantena), non semplice outlier
# ---------------------------------------------------------------------------
HARD_LIMITS = {
    "prenotazioni": {
        "notti": (1, 60), "adulti": (0, 10), "bambini": (0, 8), "neonati": (0, 3),
        "importo_totale_eur": (0, 50000), "prezzo_medio_notte_eur": (0, 3000),
        "lead_time_giorni": (0, 730),
    },
    "occupazione": {
        "camere_disponibili": (0, 500), "camere_fuori_servizio": (0, 500), "camere_occupate": (0, 500),
        "arrivi": (0, 500), "partenze": (0, 500), "ospiti_presenti": (0, 2000),
        "ricavo_camere_eur": (0, 200000),
    },
    "listino": {"tariffa_notte_bb_eur": (1, 5000), "suppl_mezza_pensione_eur": (0, 500),
                "suppl_pensione_completa_eur": (0, 500)},
    "camere": {"n_unita": (1, 500), "capienza_max": (1, 12)},
    "strutture": {"unita_totali": (1, 2000)},
    "canali": {"commissione_pct": (0, 100)},
    "promozioni": {"sconto_pct": (0, 100)},
    "recensioni": {"voto_10": (0, 10)},
}
# Outlier statistici (IQR) -> solo flag. (colonna, raggruppamento)
OUTLIER_COLUMNS = {
    "prenotazioni": [("prezzo_medio_notte_eur", ["id_struttura", "tipologia"]),
                     ("lead_time_giorni", None), ("notti", None)],
    "occupazione": [("adr_eur", ["id_struttura"])],
}

# Regole delle promozioni (dalle descrizioni del foglio Promozioni)
PROMO_RULES = {
    "EARLY60": {"min_lead": 60},
    "LASTMIN": {"max_lead": 4, "stagioni": ["bassa", "media"]},
    "SKI3": {"min_notti": 3, "area": "montagna", "periodo": "inverno", "giorni_arrivo": [6, 0, 1]},  # dom-mar
}

# ---------------------------------------------------------------------------
# Chiavi esterne controllate PRIMA del caricamento (figlio -> padre).
# L'ordine conta: i padri vengono puliti prima dei figli.
# ---------------------------------------------------------------------------
LOAD_ORDER = ["aree", "paesi", "trattamenti", "canali", "strutture", "periodi_apertura", "camere",
              "stagionalita", "eventi", "promozioni", "promozioni_canali", "listino",
              "prenotazioni", "occupazione", "recensioni"]
FOREIGN_KEYS = [
    ("strutture", ["area"], "aree", ["area"]),
    ("camere", ["id_struttura"], "strutture", ["id_struttura"]),
    ("stagionalita", ["area"], "aree", ["area"]),
    ("eventi", ["area"], "aree", ["area"]),
    ("listino", ["id_struttura", "tipologia"], "camere", ["id_struttura", "tipologia"]),
    ("prenotazioni", ["id_struttura", "tipologia"], "camere", ["id_struttura", "tipologia"]),
    ("prenotazioni", ["canale"], "canali", ["canale"]),
    ("prenotazioni", ["codice_promo"], "promozioni", ["codice_promo"]),
    ("prenotazioni", ["codice_trattamento"], "trattamenti", ["codice_trattamento"]),
    ("prenotazioni", ["codice_paese"], "paesi", ["codice_paese"]),
    ("occupazione", ["id_struttura"], "strutture", ["id_struttura"]),
    ("recensioni", ["id_prenotazione"], "prenotazioni", ["id_prenotazione"]),
]

# ---------------------------------------------------------------------------
# Schema di destinazione: colonne caricate (in ordine) e chiave primaria
# ---------------------------------------------------------------------------
TABLES = {
    "aree": ("aree", ["area"], ["area"]),
    "paesi": ("paesi", ["codice_paese", "nome"], ["codice_paese"]),
    "trattamenti": ("trattamenti", ["codice_trattamento", "descrizione"], ["codice_trattamento"]),
    "canali": ("canali", ["canale", "tipo", "commissione_pct", "note"], ["canale"]),
    "strutture": ("strutture", ["id_struttura", "nome", "comune", "provincia", "area", "tipo_struttura",
                                "stelle", "unita_totali", "servizi", "fonte", "dq_flags"], ["id_struttura"]),
    "periodi_apertura": ("periodi_apertura", ["id_struttura", "inizio_mm_gg", "fine_mm_gg"],
                         ["id_struttura", "inizio_mm_gg"]),
    "camere": ("camere", ["id_struttura", "tipologia", "n_unita", "capienza_max", "fonte"], ["id_struttura", "tipologia"]),
    "stagionalita": ("stagionalita", ["id_stagionalita", "area", "stagione", "periodo", "data_inizio",
                                      "data_fine", "dq_flags"], ["id_stagionalita"]),
    "eventi": ("eventi", ["evento", "data_inizio", "area", "data_fine", "note"], ["evento", "data_inizio"]),
    "promozioni": ("promozioni", ["codice_promo", "descrizione", "sconto_pct"], ["codice_promo"]),
    "promozioni_canali": ("promozioni_canali", ["codice_promo", "canale"], ["codice_promo", "canale"]),
    "listino": ("listino", ["id_struttura", "tipologia", "data_inizio", "data_fine", "stagione", "periodo",
                            "id_stagionalita", "tariffa_notte_bb_eur", "suppl_mezza_pensione_eur",
                            "suppl_pensione_completa_eur", "fonte", "dq_flags"],
                ["id_struttura", "tipologia", "data_inizio"]),
    "prenotazioni": ("prenotazioni", [
        "id_prenotazione", "id_prenotazione_origine", "fonte", "id_struttura", "tipologia", "data_prenotazione", "check_in", "check_out",
        "notti", "lead_time_giorni", "adulti", "bambini", "neonati", "totale_ospiti", "eta_bambini",
        "codice_trattamento", "canale", "codice_promo", "importo_totale_eur", "prezzo_medio_notte_eur",
        "stato", "data_cancellazione", "codice_paese", "codice_cliente", "note",
        "is_outlier_prezzo_medio_notte_eur", "is_outlier_lead_time_giorni", "is_outlier_notti", "dq_flags",
    ], ["id_prenotazione"]),
    "occupazione": ("occupazione_giornaliera", [
        "id_struttura", "data", "camere_disponibili", "camere_fuori_servizio", "camere_occupate", "arrivi",
        "partenze", "ospiti_presenti", "ospiti_presenti_stimati", "ricavo_camere_eur",
        "tasso_occupazione_pct", "adr_eur", "is_outlier_adr_eur", "fonte", "dq_flags",
    ], ["id_struttura", "data"]),
    "recensioni": ("recensioni", [
        "id_recensione", "id_recensione_origine", "fonte", "id_prenotazione", "data_recensione",
        "giorni_dopo_check_out", "voto_10",
        "voto_originale", "piattaforma", "titolo", "testo", "dq_flags",
    ], ["id_recensione"]),
}
# Colonne che possono restare NULL (tutte le altre sono obbligatorie)
NULLABLE = {
    "canali": ["note"],
    "strutture": ["stelle", "servizi", "dq_flags"],
    "stagionalita": ["periodo", "dq_flags"],
    "eventi": ["note"],
    "listino": ["periodo", "id_stagionalita", "suppl_mezza_pensione_eur", "suppl_pensione_completa_eur", "dq_flags"],
    "prenotazioni": ["eta_bambini", "codice_promo", "data_cancellazione", "note", "dq_flags"],
    "occupazione": ["tasso_occupazione_pct", "adr_eur", "dq_flags"],
    "recensioni": ["voto_10", "voto_originale", "titolo", "testo", "dq_flags"],
}

TABLE_REJECTED = "scarti"
TABLE_LOGS = "pipeline_logs"
TABLE_RUNS = "pipeline_runs"

_S = DB_SCHEMA
DDL = f"""
CREATE SCHEMA IF NOT EXISTS {_S};

-- ===================== tabelle di dominio =====================
CREATE TABLE IF NOT EXISTS {_S}.aree (
    area                VARCHAR(20)   PRIMARY KEY
);
CREATE TABLE IF NOT EXISTS {_S}.paesi (
    codice_paese        CHAR(2)       PRIMARY KEY,
    nome                VARCHAR(60)   NOT NULL
);
CREATE TABLE IF NOT EXISTS {_S}.trattamenti (
    codice_trattamento  VARCHAR(2)    PRIMARY KEY,
    descrizione         VARCHAR(40)   NOT NULL
);
CREATE TABLE IF NOT EXISTS {_S}.canali (
    canale              VARCHAR(30)   PRIMARY KEY,
    tipo                VARCHAR(30)   NOT NULL,
    commissione_pct     NUMERIC(5,2)  NOT NULL CHECK (commissione_pct BETWEEN 0 AND 100),
    note                TEXT
);

-- ===================== anagrafiche =====================
CREATE TABLE IF NOT EXISTS {_S}.strutture (
    id_struttura        CHAR(3)       PRIMARY KEY,
    nome                VARCHAR(60)   NOT NULL UNIQUE,
    comune              VARCHAR(60)   NOT NULL,
    provincia           CHAR(2)       NOT NULL,
    area                VARCHAR(20)   NOT NULL REFERENCES {_S}.aree (area),
    tipo_struttura      VARCHAR(20)   NOT NULL,
    stelle              SMALLINT      CHECK (stelle BETWEEN 1 AND 5),
    unita_totali        SMALLINT      NOT NULL CHECK (unita_totali > 0),
    servizi             TEXT,
    fonte               VARCHAR(40)   NOT NULL,                -- database sorgente
    dq_flags            TEXT
);
-- periodo di apertura in formato unico 'MM-GG' (ricorrente ogni anno)
CREATE TABLE IF NOT EXISTS {_S}.periodi_apertura (
    id_struttura        CHAR(3)       NOT NULL REFERENCES {_S}.strutture (id_struttura),
    inizio_mm_gg        CHAR(5)       NOT NULL CHECK (inizio_mm_gg ~ '^[0-1][0-9]-[0-3][0-9]$'),
    fine_mm_gg          CHAR(5)       NOT NULL CHECK (fine_mm_gg   ~ '^[0-1][0-9]-[0-3][0-9]$'),
    PRIMARY KEY (id_struttura, inizio_mm_gg)
);
CREATE TABLE IF NOT EXISTS {_S}.camere (
    id_struttura        CHAR(3)       NOT NULL REFERENCES {_S}.strutture (id_struttura),
    tipologia           VARCHAR(30)   NOT NULL,
    n_unita             SMALLINT      NOT NULL CHECK (n_unita > 0),
    capienza_max        SMALLINT      NOT NULL CHECK (capienza_max > 0),
    fonte               VARCHAR(40)   NOT NULL,
    PRIMARY KEY (id_struttura, tipologia)
);
CREATE TABLE IF NOT EXISTS {_S}.stagionalita (
    id_stagionalita     VARCHAR(30)   PRIMARY KEY,          -- area-AAAA-MM-GG
    area                VARCHAR(20)   NOT NULL REFERENCES {_S}.aree (area),
    stagione            VARCHAR(10)   NOT NULL CHECK (stagione IN ('chiusura','bassa','media','alta','altissima')),
    periodo             VARCHAR(10)   CHECK (periodo IN ('inverno','estate')),
    data_inizio         DATE          NOT NULL,
    data_fine           DATE          NOT NULL,
    dq_flags            TEXT,
    CHECK (data_fine >= data_inizio),
    UNIQUE (area, data_inizio)
);
CREATE TABLE IF NOT EXISTS {_S}.eventi (
    evento              VARCHAR(80)   NOT NULL,
    data_inizio         DATE          NOT NULL,
    area                VARCHAR(20)   NOT NULL REFERENCES {_S}.aree (area),
    data_fine           DATE          NOT NULL,
    note                TEXT,
    PRIMARY KEY (evento, data_inizio),
    CHECK (data_fine >= data_inizio)
);

-- ===================== tariffe e promozioni =====================
CREATE TABLE IF NOT EXISTS {_S}.promozioni (
    codice_promo        VARCHAR(10)   PRIMARY KEY,
    descrizione         TEXT          NOT NULL,
    sconto_pct          NUMERIC(5,2)  NOT NULL CHECK (sconto_pct BETWEEN 0 AND 100)
);
CREATE TABLE IF NOT EXISTS {_S}.promozioni_canali (
    codice_promo        VARCHAR(10)   NOT NULL REFERENCES {_S}.promozioni (codice_promo),
    canale              VARCHAR(30)   NOT NULL REFERENCES {_S}.canali (canale),
    PRIMARY KEY (codice_promo, canale)
);
CREATE TABLE IF NOT EXISTS {_S}.listino (
    id_struttura                CHAR(3)       NOT NULL,
    tipologia                   VARCHAR(30)   NOT NULL,
    data_inizio                 DATE          NOT NULL,
    data_fine                   DATE          NOT NULL,
    stagione                    VARCHAR(10)   NOT NULL,
    periodo                     VARCHAR(10),
    id_stagionalita             VARCHAR(30)   REFERENCES {_S}.stagionalita (id_stagionalita),
    tariffa_notte_bb_eur        NUMERIC(10,2) NOT NULL CHECK (tariffa_notte_bb_eur > 0),
    suppl_mezza_pensione_eur    NUMERIC(10,2) CHECK (suppl_mezza_pensione_eur >= 0),     -- NULL = non previsto
    suppl_pensione_completa_eur NUMERIC(10,2) CHECK (suppl_pensione_completa_eur >= 0),
    fonte                       VARCHAR(40)   NOT NULL,
    dq_flags                    TEXT,
    PRIMARY KEY (id_struttura, tipologia, data_inizio),
    FOREIGN KEY (id_struttura, tipologia) REFERENCES {_S}.camere (id_struttura, tipologia),
    CHECK (data_fine >= data_inizio)
);

-- ===================== dati operativi =====================
CREATE TABLE IF NOT EXISTS {_S}.prenotazioni (
    id_prenotazione       VARCHAR(30)   PRIMARY KEY,           -- S01-BT24-00001
    id_prenotazione_origine VARCHAR(20) NOT NULL,               -- id nel database sorgente
    fonte                 VARCHAR(40)   NOT NULL,
    id_struttura          CHAR(3)       NOT NULL,
    tipologia             VARCHAR(30)   NOT NULL,
    data_prenotazione     DATE          NOT NULL,
    check_in              DATE          NOT NULL,
    check_out             DATE          NOT NULL,
    notti                 SMALLINT      NOT NULL CHECK (notti > 0),
    lead_time_giorni      SMALLINT      NOT NULL CHECK (lead_time_giorni >= 0),
    adulti                SMALLINT      NOT NULL CHECK (adulti >= 0),
    bambini               SMALLINT      NOT NULL CHECK (bambini >= 0),
    neonati               SMALLINT      NOT NULL CHECK (neonati >= 0),
    totale_ospiti         SMALLINT      NOT NULL CHECK (totale_ospiti > 0),
    eta_bambini           SMALLINT[],                        -- NULL = età non comunicate
    codice_trattamento    VARCHAR(2)    NOT NULL REFERENCES {_S}.trattamenti (codice_trattamento),
    canale                VARCHAR(30)   NOT NULL REFERENCES {_S}.canali (canale),
    codice_promo          VARCHAR(10)   REFERENCES {_S}.promozioni (codice_promo),   -- NULL = nessuna promo
    importo_totale_eur    NUMERIC(10,2) NOT NULL CHECK (importo_totale_eur >= 0),
    prezzo_medio_notte_eur NUMERIC(10,2) NOT NULL,
    stato                 VARCHAR(10)   NOT NULL CHECK (stato IN ('confermata','cancellata','no-show')),
    cancellata            BOOLEAN       GENERATED ALWAYS AS (stato = 'cancellata') STORED,
    data_cancellazione    DATE,
    codice_paese          CHAR(2)       NOT NULL REFERENCES {_S}.paesi (codice_paese),
    codice_cliente        VARCHAR(10)   NOT NULL,
    note                  TEXT,
    is_outlier_prezzo_medio_notte_eur BOOLEAN NOT NULL DEFAULT FALSE,
    is_outlier_lead_time_giorni       BOOLEAN NOT NULL DEFAULT FALSE,
    is_outlier_notti                  BOOLEAN NOT NULL DEFAULT FALSE,
    dq_flags              TEXT,
    caricato_il           TIMESTAMPTZ   NOT NULL DEFAULT now(),
    FOREIGN KEY (id_struttura, tipologia) REFERENCES {_S}.camere (id_struttura, tipologia),
    CHECK (check_out > check_in),
    CHECK (data_prenotazione <= check_in),
    CHECK (stato = 'cancellata' OR data_cancellazione IS NULL),
    CHECK (adulti + bambini + neonati = totale_ospiti),
    UNIQUE (fonte, id_prenotazione_origine)
);
CREATE INDEX IF NOT EXISTS idx_prenotazioni_struttura_checkin ON {_S}.prenotazioni (id_struttura, check_in);
CREATE INDEX IF NOT EXISTS idx_prenotazioni_canale ON {_S}.prenotazioni (canale);
CREATE INDEX IF NOT EXISTS idx_prenotazioni_cliente ON {_S}.prenotazioni (codice_cliente);

CREATE TABLE IF NOT EXISTS {_S}.occupazione_giornaliera (
    id_struttura          CHAR(3)       NOT NULL REFERENCES {_S}.strutture (id_struttura),
    data                  DATE          NOT NULL,
    camere_disponibili    SMALLINT      NOT NULL CHECK (camere_disponibili >= 0),
    camere_fuori_servizio SMALLINT      NOT NULL CHECK (camere_fuori_servizio >= 0),
    camere_occupate       SMALLINT      NOT NULL CHECK (camere_occupate >= 0),
    arrivi                SMALLINT      NOT NULL CHECK (arrivi >= 0),
    partenze              SMALLINT      NOT NULL CHECK (partenze >= 0),
    ospiti_presenti       SMALLINT      NOT NULL CHECK (ospiti_presenti >= 0),
    ospiti_presenti_stimati BOOLEAN     NOT NULL DEFAULT FALSE,   -- TRUE = valore imputato
    ricavo_camere_eur     NUMERIC(10,2) NOT NULL CHECK (ricavo_camere_eur >= 0),
    tasso_occupazione_pct NUMERIC(5,2),                           -- NULL = struttura chiusa
    adr_eur               NUMERIC(10,2),                          -- ricavo medio per camera occupata
    is_outlier_adr_eur    BOOLEAN       NOT NULL DEFAULT FALSE,
    fonte                 VARCHAR(40)   NOT NULL,
    dq_flags              TEXT,
    caricato_il           TIMESTAMPTZ   NOT NULL DEFAULT now(),
    PRIMARY KEY (id_struttura, data),
    CHECK (camere_occupate <= camere_disponibili)
);

-- Recensioni: la struttura si ricava dalla prenotazione (nessun dato duplicato)
CREATE TABLE IF NOT EXISTS {_S}.recensioni (
    id_recensione         VARCHAR(40)   PRIMARY KEY,
    id_recensione_origine VARCHAR(30)   NOT NULL,
    fonte                 VARCHAR(40)   NOT NULL,
    id_prenotazione       VARCHAR(30)   NOT NULL REFERENCES {_S}.prenotazioni (id_prenotazione),
    data_recensione       DATE          NOT NULL,
    giorni_dopo_check_out SMALLINT      NOT NULL,
    voto_10               NUMERIC(3,1)  CHECK (voto_10 BETWEEN 0 AND 10),   -- NULL = solo testo
    voto_originale        VARCHAR(20),                                      -- come scritto nel file
    piattaforma           VARCHAR(30)   NOT NULL,
    titolo                TEXT,
    testo                 TEXT,                                             -- email/telefoni oscurati
    dq_flags              TEXT,
    caricato_il           TIMESTAMPTZ   NOT NULL DEFAULT now(),
    CHECK (voto_10 IS NOT NULL OR testo IS NOT NULL)
);
CREATE INDEX IF NOT EXISTS idx_recensioni_prenotazione ON {_S}.recensioni (id_prenotazione);

-- vista comoda: recensioni con struttura e camera
CREATE OR REPLACE VIEW {_S}.v_recensioni AS
SELECT r.*, p.id_struttura, s.nome AS struttura, p.tipologia, p.check_in, p.check_out, p.canale
FROM {_S}.recensioni r
JOIN {_S}.prenotazioni p USING (id_prenotazione)
JOIN {_S}.strutture s USING (id_struttura);

-- vista: riepilogo per fonte
CREATE OR REPLACE VIEW {_S}.v_riepilogo_fonti AS
SELECT fonte, id_struttura, count(*) AS prenotazioni,
       count(*) FILTER (WHERE dq_flags IS NOT NULL) AS prenotazioni_con_flag,
       min(check_in) AS primo_check_in, max(check_in) AS ultimo_check_in
FROM {_S}.prenotazioni GROUP BY fonte, id_struttura;

-- ===================== qualità dati e monitoraggio =====================
CREATE TABLE IF NOT EXISTS {_S}.{TABLE_REJECTED} (
    id              BIGSERIAL     PRIMARY KEY,
    tabella         VARCHAR(30)   NOT NULL,
    fonte           VARCHAR(40)   NOT NULL,
    chiave          TEXT,
    riga_sorgente   INTEGER,
    motivo          TEXT          NOT NULL,
    record_hash     CHAR(40)      NOT NULL,
    raw_record      JSONB         NOT NULL,
    scartato_il     TIMESTAMPTZ   NOT NULL DEFAULT now(),
    UNIQUE (tabella, fonte, record_hash, motivo)
);
CREATE TABLE IF NOT EXISTS {_S}.{TABLE_LOGS} (
    id        BIGSERIAL    PRIMARY KEY,
    ts        TIMESTAMPTZ  NOT NULL DEFAULT now(),
    level     VARCHAR(10)  NOT NULL,
    logger    TEXT,
    message   TEXT
);
CREATE TABLE IF NOT EXISTS {_S}.{TABLE_RUNS} (
    id                 BIGSERIAL    PRIMARY KEY,
    ts                 TIMESTAMPTZ  NOT NULL DEFAULT now(),
    status             VARCHAR(10)  NOT NULL,
    records_extracted  INTEGER,
    records_rejected   INTEGER,
    records_inserted   INTEGER,
    records_updated    INTEGER,
    sources_ok         SMALLINT,
    sources_failed     SMALLINT,
    errors             TEXT,
    details            JSONB
);
"""
