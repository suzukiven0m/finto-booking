import os

import psycopg2

# ---------------------------------------------------------------------------
# Connessione a PostgreSQL
# Le credenziali NON sono nel codice: impostare la variabile d'ambiente
# DATABASE_URL, es.  postgresql://utente:password@host:5432/buby_travel
# (il database deve già esistere; schema e tabelle vengono creati dalla pipeline).
# ---------------------------------------------------------------------------
# >>> MODIFICA QUI (oppure imposta la variabile d'ambiente DATABASE_URL) <<<
# Se la password contiene caratteri speciali (@ # / : %) vanno codificati: @ -> %40, # -> %23, / -> %2F
DB_USER = "postgres"
DB_PASSWORD = "Daniele2006"   # la password scelta quando hai installato PostgreSQL
DB_HOST = "127.0.0.1"
DB_PORT = 5432
DB_NAME = "buby_travel"

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}",
)
DB_SCHEMA = os.getenv("DB_SCHEMA", "buby_travel")


def get_connection(autocommit: bool = False):
    if "INSERISCI_LA_PASSWORD" in DATABASE_URL or "<password>" in DATABASE_URL:
        raise RuntimeError("Password di PostgreSQL non impostata: modifica DB_PASSWORD in config.py "
                           "oppure imposta la variabile d'ambiente DATABASE_URL.")
    conn = psycopg2.connect(DATABASE_URL, connect_timeout=5)
    conn.autocommit = autocommit
    return conn


# ---------------------------------------------------------------------------
# Sorgenti: un file CSV per ogni tabella. I file NON vengono uniti:
# ogni CSV diventa una tabella, collegata alle altre tramite chiavi esterne.
# ---------------------------------------------------------------------------
DATA_DIR = os.getenv("DATA_DIR", os.path.join(os.path.dirname(os.path.abspath(__file__)), "data"))
CSV_SEPARATOR = os.getenv("CSV_SEPARATOR", ",")
CSV_ENCODING = os.getenv("CSV_ENCODING", "utf-8")

SOURCES = {
    "strutture":    os.path.join(DATA_DIR, "strutture.csv"),
    "camere":       os.path.join(DATA_DIR, "camere.csv"),
    "canali":       os.path.join(DATA_DIR, "canali.csv"),
    "stagionalita": os.path.join(DATA_DIR, "stagionalita.csv"),
    "eventi":       os.path.join(DATA_DIR, "eventi.csv"),
    "listino":      os.path.join(DATA_DIR, "listino.csv"),
    "promozioni":   os.path.join(DATA_DIR, "promozioni.csv"),
    "prenotazioni": os.path.join(DATA_DIR, "prenotazioni.csv"),
    "occupazione":  os.path.join(DATA_DIR, "occupazione_giornaliera.csv"),
}

# Rinomina colonne in fase di estrazione: nomi omogenei fra le tabelle
# (tutte le date di validità -> data_inizio/data_fine, importi con suffisso _eur).
RENAME = {
    "stagionalita": {"dal": "data_inizio", "al": "data_fine"},
    "eventi": {"dal": "data_inizio", "al": "data_fine"},
    "listino": {
        "struttura": "nome_struttura", "valido_dal": "data_inizio", "valido_al": "data_fine",
        "tariffa_notte_camera_bb": "tariffa_notte_bb_eur",
        "suppl_mezza_pensione_a_persona": "suppl_mezza_pensione_eur",
        "suppl_pensione_completa_a_persona": "suppl_pensione_completa_eur",
    },
    "prenotazioni": {
        "struttura": "nome_struttura", "tipologia_camera": "tipologia",
        "trattamento": "codice_trattamento", "paese": "codice_paese",
        "importo_totale": "importo_totale_eur",
    },
    "occupazione": {"struttura": "nome_struttura", "ricavo_camere": "ricavo_camere_eur"},
}

# Chiave naturale usata nei log/quarantena per riconoscere il record
NATURAL_KEY = {
    "strutture": ["id_struttura"], "camere": ["id_struttura", "tipologia"], "canali": ["canale"],
    "stagionalita": ["area", "data_inizio"], "eventi": ["evento", "data_inizio"],
    "listino": ["id_struttura", "tipologia", "data_inizio"], "promozioni": ["codice_promo"],
    "prenotazioni": ["id_prenotazione"], "occupazione": ["nome_struttura", "data"],
}

# ---------------------------------------------------------------------------
# Parametri generali
# ---------------------------------------------------------------------------
# Oltre questa quota di scarti la pipeline si ferma (file probabilmente corrotto)
MAX_REJECT_RATIO = {"default": 0.05, "prenotazioni": 0.08, "occupazione": 0.05}

# "NA" escluso di proposito: è il codice ISO della Namibia
NA_VALUES = ["", "NULL", "null", "NaN", "nan", "None", "none", "N/A", "n/a", "-", "--"]

FUZZY_CUTOFF = 0.85   # tolleranza correzione refusi (difflib)
IQR_K = 3.0           # k=3 -> solo outlier "estremi"

# ---------------------------------------------------------------------------
# Formati: colonne per tipo (nomi DOPO il RENAME)
#   date    -> DATE ISO (YYYY-MM-DD)
#   importi -> NUMERIC(10,2) in euro, separatore decimale punto
#   pct     -> NUMERIC(5,2) da 0 a 100
#   interi  -> SMALLINT/INTEGER
# ---------------------------------------------------------------------------
DATE_FORMATS = ["%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%d/%m/%Y", "%d-%m-%y", "%d-%m-%Y", "%d.%m.%Y", "%Y/%m/%d"]
STANDARD_DATE_FORMATS = 2   # i primi N formati sono "standard" (ISO/Excel): gli altri vengono segnalati

DATE_COLUMNS = {
    "stagionalita": ["data_inizio", "data_fine"],
    "eventi": ["data_inizio", "data_fine"],
    "listino": ["data_inizio", "data_fine"],
    "prenotazioni": ["data_prenotazione", "check_in", "check_out", "data_cancellazione"],
    "occupazione": ["data"],
}
AMOUNT_COLUMNS = {
    "listino": ["tariffa_notte_bb_eur", "suppl_mezza_pensione_eur", "suppl_pensione_completa_eur"],
    "prenotazioni": ["importo_totale_eur"],
    "occupazione": ["ricavo_camere_eur"],
}
PCT_COLUMNS = {"canali": ["commissione_pct"], "promozioni": ["sconto_pct"]}
INT_COLUMNS = {
    "strutture": ["unita_totali"],
    "camere": ["n_unita", "capienza_max"],
    "prenotazioni": ["notti"],
    "occupazione": ["camere_disponibili", "camere_fuori_servizio", "camere_occupate",
                    "arrivi", "partenze", "ospiti_presenti"],
}

# ---------------------------------------------------------------------------
# Valori mancanti: campi critici (se mancano -> quarantena)
# ---------------------------------------------------------------------------
CRITICAL_COLUMNS = {
    "strutture": ["id_struttura", "nome", "localita", "area", "categoria", "unita_totali", "periodi_apertura"],
    "camere": ["id_struttura", "tipologia", "n_unita", "capienza_max"],
    "canali": ["canale", "tipo", "commissione_pct"],
    "stagionalita": ["area", "stagione", "data_inizio", "data_fine"],
    "eventi": ["evento", "area", "data_inizio", "data_fine"],
    "listino": ["id_struttura", "tipologia", "stagione", "data_inizio", "data_fine", "tariffa_notte_bb_eur"],
    "promozioni": ["codice_promo", "descrizione", "sconto_pct", "canali"],
    "prenotazioni": ["id_prenotazione", "nome_struttura", "data_prenotazione", "check_in", "check_out",
                     "tipologia", "ospiti", "codice_trattamento", "canale", "importo_totale_eur",
                     "stato", "codice_cliente"],
    "occupazione": ["data", "nome_struttura", "camere_disponibili", "camere_occupate", "ricavo_camere_eur"],
}
# Conteggi dell'occupazione: assenza = 0 (non ci sono stati arrivi/partenze/guasti)
ZERO_FILL_COLUMNS = {"occupazione": ["camere_fuori_servizio", "arrivi", "partenze"]}
PAESE_SCONOSCIUTO = "XX"   # codice ISO riservato per "paese non noto"

# ---------------------------------------------------------------------------
# Domini categorici: valori canonici + alias espliciti
# ---------------------------------------------------------------------------
AREE = ["lago", "montagna"]
TIPI_STRUTTURA = ["Hotel", "Residence"]
STAGIONI = ["chiusura", "bassa", "media", "alta", "altissima"]
PERIODI_STAGIONE = ["inverno", "estate"]

# Nomi struttura scritti in modo diverso nei file operativi -> id_struttura.
# (Le forme "nome completo" e "nome senza Hotel/Residence/Chalet" vengono generate in automatico.)
STRUTTURE_ALIASES = {
    "HRL": "S01", "Hotel Riva Lago": "S01",
    "Hotel Belvedere Stresa": "S02",
    "Res. Le Palme": "S03",
    "Hotel C. Bianche": "S04",
    "Chalet Alpino Limone": "S05", "Alpino": "S05",
    "Hotel M. Rosa": "S06",
}

TIPOLOGIE_ALIASES = {
    "STD": "Standard", "Sup.": "Superior", "Sup": "Superior",
    "Superior lago": "Superior vista lago", "Sup. vista lago": "Superior vista lago",
    "Famiglia": "Family", "Family room": "Family",
    "Mono": "Monolocale", "Bilo": "Bilocale", "Trilo": "Trilocale",
}

TRATTAMENTI = {   # codice -> descrizione
    "RO": "Solo pernottamento", "BB": "Pernottamento e colazione",
    "HB": "Mezza pensione", "FB": "Pensione completa",
}
TRATTAMENTI_ALIASES = {
    "Solo pernottamento": "RO", "SP": "RO",
    "B&B": "BB", "Pernottamento e colazione": "BB",
    "MP": "HB", "Mezza pensione": "HB",
    "PC": "FB", "Pensione completa": "FB",
}

CANALI_ALIASES = {
    "Diretto - sito": "Sito ufficiale", "sito": "Sito ufficiale", "Sito web": "Sito ufficiale",
    "Sito": "Sito ufficiale",
    "Stay Hub": "StayHub", "Travel Nest": "TravelNest",
    "T.O.": "Tour operator", "TO": "Tour operator",
    "Agenzia": "Agenzia viaggi", "AdV": "Agenzia viaggi",
    "Email": "Telefono/Email", "Telefono": "Telefono/Email", "Diretto - tel": "Telefono/Email",
    "Corporate": "Convenzione aziendale", "Azienda": "Convenzione aziendale",
}
PROMO_CANALI_TUTTI = "Tutti"

STATI = ["confermata", "cancellata", "no-show"]
STATI_ALIASES = {"annullata": "cancellata", "noshow": "no-show", "No show": "no-show"}

PAESI = {   # ISO 3166-1 alpha-2 -> nome
    "IT": "Italia", "DE": "Germania", "FR": "Francia", "CH": "Svizzera", "GB": "Regno Unito",
    "NL": "Paesi Bassi", "US": "Stati Uniti", "AT": "Austria", "BE": "Belgio", "ES": "Spagna",
    "SE": "Svezia", "PL": "Polonia", PAESE_SCONOSCIUTO: "Sconosciuto",
}
PAESI_ALIASES = {
    "ITA": "IT", "DEU": "DE", "FRA": "FR", "CHE": "CH", "GBR": "GB", "UK": "GB", "NLD": "NL",
    "USA": "US", "AUT": "AT", "BEL": "BE", "ESP": "ES", "SWE": "SE", "POL": "PL",
    "Olanda": "NL", "Inghilterra": "GB",
}
PAESI_ALIASES.update({nome: cod for cod, nome in PAESI.items() if cod != PAESE_SCONOSCIUTO})

MESI_IT = {m: i for i, m in enumerate(
    ["gennaio", "febbraio", "marzo", "aprile", "maggio", "giugno", "luglio",
     "agosto", "settembre", "ottobre", "novembre", "dicembre"], 1)}

# Età sotto la quale un bambino è considerato neonato (culla, non occupa posto letto)
ETA_NEONATO = 2

# ---------------------------------------------------------------------------
# Limiti fisici/di business: oltre -> errore (quarantena), non semplice outlier
# ---------------------------------------------------------------------------
HARD_LIMITS = {
    "prenotazioni": {
        "notti": (1, 60), "adulti": (0, 10), "bambini": (0, 8), "neonati": (0, 3),
        "importo_totale_eur": (0, 50000), "prezzo_medio_notte_eur": (0, 3000),
        "lead_time_giorni": (0, 730),
    },
    "occupazione": {
        "camere_disponibili": (0, 500), "camere_fuori_servizio": (0, 500), "camere_occupate": (0, 500),
        "arrivi": (0, 500), "partenze": (0, 500), "ospiti_presenti": (0, 2000),
        "ricavo_camere_eur": (0, 200000),
    },
    "listino": {"tariffa_notte_bb_eur": (1, 5000), "suppl_mezza_pensione_eur": (0, 500),
                "suppl_pensione_completa_eur": (0, 500)},
    "camere": {"n_unita": (1, 500), "capienza_max": (1, 12)},
    "strutture": {"unita_totali": (1, 2000)},
    "canali": {"commissione_pct": (0, 100)},
    "promozioni": {"sconto_pct": (0, 100)},
}
# Outlier statistici (IQR) -> solo flag. (colonna, raggruppamento)
OUTLIER_COLUMNS = {
    "prenotazioni": [("prezzo_medio_notte_eur", ["id_struttura", "tipologia"]),
                     ("lead_time_giorni", None), ("notti", None)],
    "occupazione": [("adr_eur", ["id_struttura"])],
}

# Regole delle promozioni (dalle descrizioni del foglio Promozioni)
PROMO_RULES = {
    "EARLY60": {"min_lead": 60},
    "LASTMIN": {"max_lead": 4, "stagioni": ["bassa", "media"]},
    "SKI3": {"min_notti": 3, "area": "montagna", "periodo": "inverno", "giorni_arrivo": [6, 0, 1]},  # dom-mar
}

# ---------------------------------------------------------------------------
# Chiavi esterne controllate PRIMA del caricamento (figlio -> padre).
# L'ordine conta: i padri vengono puliti prima dei figli.
# ---------------------------------------------------------------------------
LOAD_ORDER = ["aree", "paesi", "trattamenti", "canali", "strutture", "periodi_apertura", "camere",
              "stagionalita", "eventi", "promozioni", "promozioni_canali", "listino",
              "prenotazioni", "occupazione"]
FOREIGN_KEYS = [
    ("strutture", ["area"], "aree", ["area"]),
    ("camere", ["id_struttura"], "strutture", ["id_struttura"]),
    ("stagionalita", ["area"], "aree", ["area"]),
    ("eventi", ["area"], "aree", ["area"]),
    ("listino", ["id_struttura", "tipologia"], "camere", ["id_struttura", "tipologia"]),
    ("prenotazioni", ["id_struttura", "tipologia"], "camere", ["id_struttura", "tipologia"]),
    ("prenotazioni", ["canale"], "canali", ["canale"]),
    ("prenotazioni", ["codice_promo"], "promozioni", ["codice_promo"]),
    ("prenotazioni", ["codice_trattamento"], "trattamenti", ["codice_trattamento"]),
    ("prenotazioni", ["codice_paese"], "paesi", ["codice_paese"]),
    ("occupazione", ["id_struttura"], "strutture", ["id_struttura"]),
]

# ---------------------------------------------------------------------------
# Schema di destinazione: colonne caricate (in ordine) e chiave primaria
# ---------------------------------------------------------------------------
TABLES = {
    "aree": ("aree", ["area"], ["area"]),
    "paesi": ("paesi", ["codice_paese", "nome"], ["codice_paese"]),
    "trattamenti": ("trattamenti", ["codice_trattamento", "descrizione"], ["codice_trattamento"]),
    "canali": ("canali", ["canale", "tipo", "commissione_pct", "note"], ["canale"]),
    "strutture": ("strutture", ["id_struttura", "nome", "comune", "provincia", "area", "tipo_struttura",
                                "stelle", "unita_totali", "servizi", "dq_flags"], ["id_struttura"]),
    "periodi_apertura": ("periodi_apertura", ["id_struttura", "inizio_mm_gg", "fine_mm_gg"],
                         ["id_struttura", "inizio_mm_gg"]),
    "camere": ("camere", ["id_struttura", "tipologia", "n_unita", "capienza_max"], ["id_struttura", "tipologia"]),
    "stagionalita": ("stagionalita", ["id_stagionalita", "area", "stagione", "periodo", "data_inizio",
                                      "data_fine", "dq_flags"], ["id_stagionalita"]),
    "eventi": ("eventi", ["evento", "data_inizio", "area", "data_fine", "note"], ["evento", "data_inizio"]),
    "promozioni": ("promozioni", ["codice_promo", "descrizione", "sconto_pct"], ["codice_promo"]),
    "promozioni_canali": ("promozioni_canali", ["codice_promo", "canale"], ["codice_promo", "canale"]),
    "listino": ("listino", ["id_struttura", "tipologia", "data_inizio", "data_fine", "stagione", "periodo",
                            "id_stagionalita", "tariffa_notte_bb_eur", "suppl_mezza_pensione_eur",
                            "suppl_pensione_completa_eur", "dq_flags"],
                ["id_struttura", "tipologia", "data_inizio"]),
    "prenotazioni": ("prenotazioni", [
        "id_prenotazione", "id_struttura", "tipologia", "data_prenotazione", "check_in", "check_out",
        "notti", "lead_time_giorni", "adulti", "bambini", "neonati", "totale_ospiti", "eta_bambini",
        "codice_trattamento", "canale", "codice_promo", "importo_totale_eur", "prezzo_medio_notte_eur",
        "stato", "data_cancellazione", "codice_paese", "codice_cliente", "note",
        "is_outlier_prezzo_medio_notte_eur", "is_outlier_lead_time_giorni", "is_outlier_notti", "dq_flags",
    ], ["id_prenotazione"]),
    "occupazione": ("occupazione_giornaliera", [
        "id_struttura", "data", "camere_disponibili", "camere_fuori_servizio", "camere_occupate", "arrivi",
        "partenze", "ospiti_presenti", "ospiti_presenti_stimati", "ricavo_camere_eur",
        "tasso_occupazione_pct", "adr_eur", "is_outlier_adr_eur", "dq_flags",
    ], ["id_struttura", "data"]),
}
# Colonne che possono restare NULL (tutte le altre sono obbligatorie)
NULLABLE = {
    "canali": ["note"],
    "strutture": ["stelle", "servizi", "dq_flags"],
    "stagionalita": ["periodo", "dq_flags"],
    "eventi": ["note"],
    "listino": ["periodo", "id_stagionalita", "suppl_mezza_pensione_eur", "suppl_pensione_completa_eur", "dq_flags"],
    "prenotazioni": ["eta_bambini", "codice_promo", "data_cancellazione", "note", "dq_flags"],
    "occupazione": ["tasso_occupazione_pct", "adr_eur", "dq_flags"],
}

TABLE_REJECTED = "scarti"
TABLE_LOGS = "pipeline_logs"
TABLE_RUNS = "pipeline_runs"

_S = DB_SCHEMA
DDL = f"""
CREATE SCHEMA IF NOT EXISTS {_S};

-- ===================== tabelle di dominio =====================
CREATE TABLE IF NOT EXISTS {_S}.aree (
    area                VARCHAR(20)   PRIMARY KEY
);
CREATE TABLE IF NOT EXISTS {_S}.paesi (
    codice_paese        CHAR(2)       PRIMARY KEY,
    nome                VARCHAR(60)   NOT NULL
);
CREATE TABLE IF NOT EXISTS {_S}.trattamenti (
    codice_trattamento  VARCHAR(2)    PRIMARY KEY,
    descrizione         VARCHAR(40)   NOT NULL
);
CREATE TABLE IF NOT EXISTS {_S}.canali (
    canale              VARCHAR(30)   PRIMARY KEY,
    tipo                VARCHAR(30)   NOT NULL,
    commissione_pct     NUMERIC(5,2)  NOT NULL CHECK (commissione_pct BETWEEN 0 AND 100),
    note                TEXT
);

-- ===================== anagrafiche =====================
CREATE TABLE IF NOT EXISTS {_S}.strutture (
    id_struttura        CHAR(3)       PRIMARY KEY,
    nome                VARCHAR(60)   NOT NULL UNIQUE,
    comune              VARCHAR(60)   NOT NULL,
    provincia           CHAR(2)       NOT NULL,
    area                VARCHAR(20)   NOT NULL REFERENCES {_S}.aree (area),
    tipo_struttura      VARCHAR(20)   NOT NULL,
    stelle              SMALLINT      CHECK (stelle BETWEEN 1 AND 5),
    unita_totali        SMALLINT      NOT NULL CHECK (unita_totali > 0),
    servizi             TEXT,
    dq_flags            TEXT
);
-- periodo di apertura in formato unico 'MM-GG' (ricorrente ogni anno)
CREATE TABLE IF NOT EXISTS {_S}.periodi_apertura (
    id_struttura        CHAR(3)       NOT NULL REFERENCES {_S}.strutture (id_struttura),
    inizio_mm_gg        CHAR(5)       NOT NULL CHECK (inizio_mm_gg ~ '^[0-1][0-9]-[0-3][0-9]$'),
    fine_mm_gg          CHAR(5)       NOT NULL CHECK (fine_mm_gg   ~ '^[0-1][0-9]-[0-3][0-9]$'),
    PRIMARY KEY (id_struttura, inizio_mm_gg)
);
CREATE TABLE IF NOT EXISTS {_S}.camere (
    id_struttura        CHAR(3)       NOT NULL REFERENCES {_S}.strutture (id_struttura),
    tipologia           VARCHAR(30)   NOT NULL,
    n_unita             SMALLINT      NOT NULL CHECK (n_unita > 0),
    capienza_max        SMALLINT      NOT NULL CHECK (capienza_max > 0),
    PRIMARY KEY (id_struttura, tipologia)
);
CREATE TABLE IF NOT EXISTS {_S}.stagionalita (
    id_stagionalita     VARCHAR(30)   PRIMARY KEY,          -- area-AAAA-MM-GG
    area                VARCHAR(20)   NOT NULL REFERENCES {_S}.aree (area),
    stagione            VARCHAR(10)   NOT NULL CHECK (stagione IN ('chiusura','bassa','media','alta','altissima')),
    periodo             VARCHAR(10)   CHECK (periodo IN ('inverno','estate')),
    data_inizio         DATE          NOT NULL,
    data_fine           DATE          NOT NULL,
    dq_flags            TEXT,
    CHECK (data_fine >= data_inizio),
    UNIQUE (area, data_inizio)
);
CREATE TABLE IF NOT EXISTS {_S}.eventi (
    evento              VARCHAR(80)   NOT NULL,
    data_inizio         DATE          NOT NULL,
    area                VARCHAR(20)   NOT NULL REFERENCES {_S}.aree (area),
    data_fine           DATE          NOT NULL,
    note                TEXT,
    PRIMARY KEY (evento, data_inizio),
    CHECK (data_fine >= data_inizio)
);

-- ===================== tariffe e promozioni =====================
CREATE TABLE IF NOT EXISTS {_S}.promozioni (
    codice_promo        VARCHAR(10)   PRIMARY KEY,
    descrizione         TEXT          NOT NULL,
    sconto_pct          NUMERIC(5,2)  NOT NULL CHECK (sconto_pct BETWEEN 0 AND 100)
);
CREATE TABLE IF NOT EXISTS {_S}.promozioni_canali (
    codice_promo        VARCHAR(10)   NOT NULL REFERENCES {_S}.promozioni (codice_promo),
    canale              VARCHAR(30)   NOT NULL REFERENCES {_S}.canali (canale),
    PRIMARY KEY (codice_promo, canale)
);
CREATE TABLE IF NOT EXISTS {_S}.listino (
    id_struttura                CHAR(3)       NOT NULL,
    tipologia                   VARCHAR(30)   NOT NULL,
    data_inizio                 DATE          NOT NULL,
    data_fine                   DATE          NOT NULL,
    stagione                    VARCHAR(10)   NOT NULL,
    periodo                     VARCHAR(10),
    id_stagionalita             VARCHAR(30)   REFERENCES {_S}.stagionalita (id_stagionalita),
    tariffa_notte_bb_eur        NUMERIC(10,2) NOT NULL CHECK (tariffa_notte_bb_eur > 0),
    suppl_mezza_pensione_eur    NUMERIC(10,2) CHECK (suppl_mezza_pensione_eur >= 0),     -- NULL = non previsto
    suppl_pensione_completa_eur NUMERIC(10,2) CHECK (suppl_pensione_completa_eur >= 0),
    dq_flags                    TEXT,
    PRIMARY KEY (id_struttura, tipologia, data_inizio),
    FOREIGN KEY (id_struttura, tipologia) REFERENCES {_S}.camere (id_struttura, tipologia),
    CHECK (data_fine >= data_inizio)
);

-- ===================== dati operativi =====================
CREATE TABLE IF NOT EXISTS {_S}.prenotazioni (
    id_prenotazione       VARCHAR(12)   PRIMARY KEY,
    id_struttura          CHAR(3)       NOT NULL,
    tipologia             VARCHAR(30)   NOT NULL,
    data_prenotazione     DATE          NOT NULL,
    check_in              DATE          NOT NULL,
    check_out             DATE          NOT NULL,
    notti                 SMALLINT      NOT NULL CHECK (notti > 0),
    lead_time_giorni      SMALLINT      NOT NULL CHECK (lead_time_giorni >= 0),
    adulti                SMALLINT      NOT NULL CHECK (adulti >= 0),
    bambini               SMALLINT      NOT NULL CHECK (bambini >= 0),
    neonati               SMALLINT      NOT NULL CHECK (neonati >= 0),
    totale_ospiti         SMALLINT      NOT NULL CHECK (totale_ospiti > 0),
    eta_bambini           SMALLINT[],                        -- NULL = età non comunicate
    codice_trattamento    VARCHAR(2)    NOT NULL REFERENCES {_S}.trattamenti (codice_trattamento),
    canale                VARCHAR(30)   NOT NULL REFERENCES {_S}.canali (canale),
    codice_promo          VARCHAR(10)   REFERENCES {_S}.promozioni (codice_promo),   -- NULL = nessuna promo
    importo_totale_eur    NUMERIC(10,2) NOT NULL CHECK (importo_totale_eur >= 0),
    prezzo_medio_notte_eur NUMERIC(10,2) NOT NULL,
    stato                 VARCHAR(10)   NOT NULL CHECK (stato IN ('confermata','cancellata','no-show')),
    cancellata            BOOLEAN       GENERATED ALWAYS AS (stato = 'cancellata') STORED,
    data_cancellazione    DATE,
    codice_paese          CHAR(2)       NOT NULL REFERENCES {_S}.paesi (codice_paese),
    codice_cliente        VARCHAR(10)   NOT NULL,
    note                  TEXT,
    is_outlier_prezzo_medio_notte_eur BOOLEAN NOT NULL DEFAULT FALSE,
    is_outlier_lead_time_giorni       BOOLEAN NOT NULL DEFAULT FALSE,
    is_outlier_notti                  BOOLEAN NOT NULL DEFAULT FALSE,
    dq_flags              TEXT,
    caricato_il           TIMESTAMPTZ   NOT NULL DEFAULT now(),
    FOREIGN KEY (id_struttura, tipologia) REFERENCES {_S}.camere (id_struttura, tipologia),
    CHECK (check_out > check_in),
    CHECK (data_prenotazione <= check_in),
    CHECK (stato = 'cancellata' OR data_cancellazione IS NULL),
    CHECK (adulti + bambini + neonati = totale_ospiti)
);
CREATE INDEX IF NOT EXISTS idx_prenotazioni_struttura_checkin ON {_S}.prenotazioni (id_struttura, check_in);
CREATE INDEX IF NOT EXISTS idx_prenotazioni_canale ON {_S}.prenotazioni (canale);
CREATE INDEX IF NOT EXISTS idx_prenotazioni_cliente ON {_S}.prenotazioni (codice_cliente);

CREATE TABLE IF NOT EXISTS {_S}.occupazione_giornaliera (
    id_struttura          CHAR(3)       NOT NULL REFERENCES {_S}.strutture (id_struttura),
    data                  DATE          NOT NULL,
    camere_disponibili    SMALLINT      NOT NULL CHECK (camere_disponibili >= 0),
    camere_fuori_servizio SMALLINT      NOT NULL CHECK (camere_fuori_servizio >= 0),
    camere_occupate       SMALLINT      NOT NULL CHECK (camere_occupate >= 0),
    arrivi                SMALLINT      NOT NULL CHECK (arrivi >= 0),
    partenze              SMALLINT      NOT NULL CHECK (partenze >= 0),
    ospiti_presenti       SMALLINT      NOT NULL CHECK (ospiti_presenti >= 0),
    ospiti_presenti_stimati BOOLEAN     NOT NULL DEFAULT FALSE,   -- TRUE = valore imputato
    ricavo_camere_eur     NUMERIC(10,2) NOT NULL CHECK (ricavo_camere_eur >= 0),
    tasso_occupazione_pct NUMERIC(5,2),                           -- NULL = struttura chiusa
    adr_eur               NUMERIC(10,2),                          -- ricavo medio per camera occupata
    is_outlier_adr_eur    BOOLEAN       NOT NULL DEFAULT FALSE,
    dq_flags              TEXT,
    caricato_il           TIMESTAMPTZ   NOT NULL DEFAULT now(),
    PRIMARY KEY (id_struttura, data),
    CHECK (camere_occupate <= camere_disponibili)
);

-- ===================== qualità dati e monitoraggio =====================
CREATE TABLE IF NOT EXISTS {_S}.{TABLE_REJECTED} (
    id              BIGSERIAL     PRIMARY KEY,
    tabella         VARCHAR(30)   NOT NULL,
    chiave          TEXT,
    riga_sorgente   INTEGER,
    motivo          TEXT          NOT NULL,
    record_hash     CHAR(40)      NOT NULL,
    raw_record      JSONB         NOT NULL,
    scartato_il     TIMESTAMPTZ   NOT NULL DEFAULT now(),
    UNIQUE (tabella, record_hash, motivo)
);
CREATE TABLE IF NOT EXISTS {_S}.{TABLE_LOGS} (
    id        BIGSERIAL    PRIMARY KEY,
    ts        TIMESTAMPTZ  NOT NULL DEFAULT now(),
    level     VARCHAR(10)  NOT NULL,
    logger    TEXT,
    message   TEXT
);
CREATE TABLE IF NOT EXISTS {_S}.{TABLE_RUNS} (
    id                 BIGSERIAL    PRIMARY KEY,
    ts                 TIMESTAMPTZ  NOT NULL DEFAULT now(),
    status             VARCHAR(10)  NOT NULL,
    records_extracted  INTEGER,
    records_rejected   INTEGER,
    records_inserted   INTEGER,
    records_updated    INTEGER,
    errors             TEXT,
    details            JSONB
);
"""
