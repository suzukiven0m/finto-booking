from prefect import flow

from tasks import (
    extract_sources, merge_sources, profile_data, standardize_formats, clean_categoricals,
    handle_missing_values, handle_numeric_outliers, check_business_rules, quarantine_rejected,
    validate_data, load_data, log_execution, logger,
)


@flow(name="buby_travel_etl_multi_db")
def buby_travel_pipeline():
    """Pipeline ETL: 6 database sorgente (uno per struttura) -> Unione -> Profiling -> Formati
    -> Categoriche -> Mancanti -> Outlier -> Regole di business -> Quarantena -> Validazione
    -> database PostgreSQL unico (tabelle collegate da chiavi esterne)"""
    extracted, report = 0, {}
    try:
        # ESTRAZIONE: ogni database sorgente viene letto separatamente
        per_source, report = extract_sources()
        ok = sum(r["stato"] == "OK" for r in report.values())
        failed = len(report) - ok

        # UNIONE: i dati delle fonti confluiscono in un unico insieme per tabella
        raw = merge_sources(per_source)
        extracted = sum(len(df) for df in raw.values())

        # ANALISI DELLA STRUTTURA (sui dati uniti)
        profile = profile_data(raw)

        # PULIZIA
        tables = standardize_formats(raw)          # date, importi, interi, ospiti, voti, periodi di apertura
        tables = clean_categoricals(tables)        # spazi, maiuscole, refusi, alias + struttura coerente con la fonte
        tables = handle_missing_values(tables)     # strategia per colonna
        tables = handle_numeric_outliers(tables)   # limiti rigidi + flag outlier IQR
        tables = check_business_rules(tables)      # regole logiche + una sola versione delle tabelle condivise

        # QUARANTENA (gli scartati finiscono nella tabella 'scarti', con la fonte di provenienza)
        clean, rejected, reasons = quarantine_rejected(tables, raw)

        # VALIDAZIONE FINALE
        valid = validate_data(clean)

        # CARICAMENTO nel database unico
        result = load_data(valid, rejected)

        # MONITORAGGIO: PARTIAL se qualche fonte non è stata letta
        inserted = sum(v["inserted"] for v in result.values() if isinstance(v, dict))
        updated = sum(v["updated"] for v in result.values() if isinstance(v, dict))
        log_execution(
            status="SUCCESS" if failed == 0 else "PARTIAL", extracted=extracted, rejected=len(rejected),
            inserted=inserted, updated=updated, sources_ok=ok, sources_failed=failed,
            errors="; ".join(f"{n}: {r['errore']}" for n, r in report.items() if r["stato"] != "OK"),
            details={"fonti": report, "profile": profile, "rejected_by_reason": reasons, "load": result},
        )
        return result

    except Exception as e:
        try:
            ok = sum(r.get("stato") == "OK" for r in report.values())
            log_execution(status="ERROR", extracted=extracted, sources_ok=ok,
                          sources_failed=len(report) - ok, errors=str(e), details={"fonti": report})
        except Exception:
            logger.error("Impossibile scrivere il riepilogo di errore su PostgreSQL.")
        raise


if __name__ == "__main__":
    buby_travel_pipeline()
