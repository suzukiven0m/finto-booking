from prefect import flow

from tasks import (
    extract_data, profile_data, standardize_formats, clean_categoricals, handle_missing_values,
    handle_numeric_outliers, check_business_rules, quarantine_rejected, validate_data,
    load_data, log_execution, logger,
)


@flow(name="buby_travel_etl_pipeline")
def buby_travel_pipeline():
    """Pipeline ETL: CSV -> Profiling -> Formati -> Categoriche -> Mancanti -> Outlier
    -> Regole di business -> Quarantena -> Validazione -> PostgreSQL (tabelle collegate da FK)"""
    extracted = 0
    try:
        # ESTRAZIONE: ogni CSV resta una tabella separata (nessuna unione dei file)
        raw = extract_data()
        extracted = sum(len(df) for df in raw.values())

        # ANALISI DELLA STRUTTURA
        profile = profile_data(raw)

        # PULIZIA
        tables = standardize_formats(raw)          # date, importi, interi, ospiti, periodi di apertura
        tables = clean_categoricals(tables)        # spazi, maiuscole, refusi, alias -> valori canonici/FK
        tables = handle_missing_values(tables)     # strategia per colonna
        tables = handle_numeric_outliers(tables)   # limiti rigidi + flag outlier IQR
        tables = check_business_rules(tables)      # regole logiche

        # QUARANTENA (i record scartati finiscono nella tabella 'scarti', non vengono persi)
        clean, rejected, reasons = quarantine_rejected(tables, raw)

        # VALIDAZIONE FINALE
        valid = validate_data(clean)

        # CARICAMENTO
        result = load_data(valid, rejected)

        # MONITORAGGIO
        inserted = sum(v["inserted"] for v in result.values() if isinstance(v, dict))
        updated = sum(v["updated"] for v in result.values() if isinstance(v, dict))
        log_execution(
            status="SUCCESS", extracted=extracted, rejected=len(rejected),
            inserted=inserted, updated=updated,
            details={"profile": profile, "rejected_by_reason": reasons, "load": result},
        )
        return result

    except Exception as e:
        try:
            log_execution(status="ERROR", extracted=extracted, errors=str(e))
        except Exception:
            logger.error("Impossibile scrivere il riepilogo di errore su PostgreSQL.")
        raise


if __name__ == "__main__":
    buby_travel_pipeline()
