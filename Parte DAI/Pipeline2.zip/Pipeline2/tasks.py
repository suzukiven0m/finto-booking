import difflib
import hashlib
import json
import logging
import os
import re
from datetime import date, datetime

import numpy as np
import pandas as pd
from prefect import task
from psycopg2.extensions import AsIs, register_adapter
from psycopg2.extras import Json, execute_values

from config import (
    AMOUNT_COLUMNS, AREE, CANALI_ALIASES, CRITICAL_COLUMNS, DATE_COLUMNS, DATE_FORMATS, DB_SCHEMA, DDL,
    ETA_NEONATO, EXPECTED_COLUMNS, REQUIRED_COLUMNS, FOREIGN_KEYS, GIORNI_MAX_RECENSIONE, FUZZY_CUTOFF, HARD_LIMITS, INT_COLUMNS, IQR_K, LOAD_ORDER, MAX_REJECT_RATIO,
    MESI_IT, NA_VALUES, NATURAL_KEY, NULLABLE, OPTIONAL_SOURCES, OUTLIER_COLUMNS, PIATTAFORME, PIATTAFORME_ALIASES, PAESE_SCONOSCIUTO, PAESI, PAESI_ALIASES,
    PCT_COLUMNS, PERIODI_STAGIONE, PROMO_CANALI_TUTTI, PROMO_RULES, RENAME, STAGIONI,
    LOCAL_TABLES, MIN_SOURCES_OK, ORIGIN_ID_COLUMNS, PREFIX_IDS, SHARED_TABLES, SOURCE_DATABASES,
    SOURCE_ERROR_POLICY, SOURCE_TABLES,
    STANDARD_DATE_FORMATS, STATI, STATI_ALIASES, STRUTTURE_ALIASES, TABLE_LOGS, TABLE_REJECTED, TABLE_RUNS,
    TABLES, TIPI_STRUTTURA, TIPOLOGIE_ALIASES, TRATTAMENTI, TRATTAMENTI_ALIASES, ZERO_FILL_COLUMNS,
    get_connection,
)

# psycopg2 non sa adattare i tipi numpy: li registriamo come numeri Python
for _t in (np.int8, np.int16, np.int32, np.int64, np.float32, np.float64):
    register_adapter(_t, AsIs)
register_adapter(np.bool_, lambda v: AsIs("TRUE" if v else "FALSE"))

# Colonne tecniche aggiunte dalla pipeline (non vengono caricate)
_TECH = ["_riga", "_hash", "_reject_reason", "_fonte_struttura"]


# ---------------------------------------------------------------------------
# Logging: console + tabella PostgreSQL pipeline_logs
# ---------------------------------------------------------------------------
class PostgresLogHandler(logging.Handler):
    """Scrive ogni record di log sulla tabella pipeline_logs (niente file locali)."""

    def __init__(self):
        super().__init__()
        self._conn = None
        self._disabled = False

    def emit(self, record: logging.LogRecord):
        if self._disabled:
            return
        try:
            if self._conn is None or self._conn.closed:
                self._conn = get_connection(autocommit=True)
                with self._conn.cursor() as cur:
                    cur.execute(DDL)
            with self._conn.cursor() as cur:
                cur.execute(
                    f"INSERT INTO {DB_SCHEMA}.{TABLE_LOGS} (level, logger, message) VALUES (%s, %s, %s)",
                    (record.levelname, record.name, record.getMessage()),
                )
        except Exception:
            # Un problema di logging non deve mai far fallire la pipeline
            self._disabled = True
            self.handleError(record)


logger = logging.getLogger("buby_travel_pipeline")
if not logger.handlers:
    logger.setLevel(logging.INFO)
    logger.propagate = False
    _fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(name)s - %(message)s")
    _console = logging.StreamHandler()
    _console.setFormatter(_fmt)
    logger.addHandler(_console)
    logger.addHandler(PostgresLogHandler())


# ---------------------------------------------------------------------------
# Helper generici
# ---------------------------------------------------------------------------
def _copy(tables: dict) -> dict:
    return {k: v.copy() for k, v in tables.items()}


def _mask(mask: pd.Series) -> pd.Series:
    return mask.fillna(False).astype(bool)


def _append(df: pd.DataFrame, mask: pd.Series, column: str, text: str):
    """Aggiunge `text` (separato da ';') alla colonna di tracciamento per le righe in mask."""
    cur = df.loc[mask, column]
    df.loc[mask, column] = cur.where(cur == "", cur + ";") + text


def _reject(df: pd.DataFrame, mask: pd.Series, reason: str, table: str) -> int:
    mask = _mask(mask)
    n = int(mask.sum())
    if n:
        _append(df, mask, "_reject_reason", reason)
        logger.warning(f"[{table}] regola bloccante '{reason}': {n} record verso la quarantena.")
    return n


def _flag(df: pd.DataFrame, mask: pd.Series, flag: str, description: str, table: str) -> int:
    mask = _mask(mask)
    n = int(mask.sum())
    if n:
        _append(df, mask, "dq_flags", flag)
        logger.warning(f"[{table}] anomalia non bloccante '{flag}' ({description}): {n} record (caricati, ma flaggati).")
    return n


def _key(value) -> str:
    """Chiave di confronto: minuscolo, senza spazi/punteggiatura."""
    return re.sub(r"[\s_\-./&]+", "", str(value)).lower()


def _map_values(series: pd.Series, targets: dict, col: str, table: str, canonical_forms=None) -> pd.Series:
    """Riconduce ogni valore a un target (spazi, maiuscole, alias, refusi tramite difflib).
    `targets`: {forma_accettata: valore_canonico}. Valori non riconducibili -> NA.
    Vengono loggate solo le correzioni (i valori già in forma canonica no)."""
    canonical_forms = set(canonical_forms if canonical_forms is not None else targets.values())
    cmap = {_key(k): v for k, v in targets.items()}
    counts = series.dropna().value_counts()
    mapping = {}
    for raw in counts.index:
        k = _key(raw)
        if k in cmap:
            mapping[raw] = cmap[k]
        else:
            close = difflib.get_close_matches(k, list(cmap), n=1, cutoff=FUZZY_CUTOFF)
            mapping[raw] = cmap[close[0]] if close else None
        if raw not in canonical_forms:
            esito = f"'{mapping[raw]}'" if mapping[raw] is not None else "NON RICONOSCIUTO"
            logger.warning(f"[{table}] categorica '{col}': '{raw}' -> {esito} ({counts[raw]} righe)")
    return series.map(mapping).astype(object).where(lambda s: s.notna(), None)


def _normalize_categorical(series, canonical: list, aliases: dict, col: str, table: str) -> pd.Series:
    targets = {c: c for c in canonical}
    targets.update(aliases)
    return _map_values(series, targets, col, table, canonical_forms=canonical)


def _parse_dates(series: pd.Series, col: str, table: str) -> pd.Series:
    """Date con formati eterogenei: prova i formati di DATE_FORMATS in ordine -> datetime64."""
    result = pd.Series(pd.NaT, index=series.index, dtype="datetime64[ns]")
    remaining = series.notna()
    for i, fmt in enumerate(DATE_FORMATS):
        if not remaining.any():
            break
        parsed = pd.to_datetime(series[remaining], format=fmt, errors="coerce")
        ok = parsed.notna()
        if ok.any():
            result.loc[parsed.index[ok]] = parsed[ok].astype("datetime64[ns]")
            remaining.loc[parsed.index[ok]] = False
            if i >= STANDARD_DATE_FORMATS:
                logger.warning(f"[{table}] date '{col}': {int(ok.sum())} valori nel formato non standard "
                               f"'{fmt}', normalizzati a AAAA-MM-GG.")
    return result.dt.normalize()


_PLAIN_NUMBER = r"^-?\d+(\.\d+)?$"


def _parse_amount(series: pd.Series, col: str, table: str) -> pd.Series:
    """Importi/percentuali in formati misti ('€ 1.234,56', '965,64', '1111 EUR', '10%') -> float."""
    s = series.astype("string")
    t = (s.str.replace(r"(?i)€|\beur(o)?\b|%", "", regex=True)
          .str.replace(r"\s+", "", regex=True))
    has_comma = t.str.contains(",", na=False)
    # formato italiano: il punto separa le migliaia, la virgola i decimali
    t = t.where(~has_comma, t.str.replace(".", "", regex=False).str.replace(",", ".", regex=False))
    out = pd.to_numeric(t, errors="coerce").astype("float64")
    non_std = s.notna() & ~s.str.match(_PLAIN_NUMBER, na=False) & out.notna()
    if non_std.any():
        esempi = s[non_std].unique()[:4].tolist()
        logger.warning(f"[{table}] importi '{col}': {int(non_std.sum())} valori in formato non standard "
                       f"(es. {esempi}) normalizzati a numero con 2 decimali.")
    return out.round(2)


def _parse_int(series: pd.Series) -> pd.Series:
    num = pd.to_numeric(series, errors="coerce")
    return num.where(num == num.round()).astype("Int64")


_RE_ADULTI = re.compile(r"(\d+)\s*(?:adult[oi]|ad\.?|a)(?![a-z])", re.I)
_RE_BAMBINI = re.compile(r"(\d+)\s*(?:bambin[oi]|bamb\.?|b)(?![a-z])", re.I)
_RE_NEONATI = re.compile(r"(\d+)\s*(?:neonat[oi]|neon\.?|n)(?![a-z])", re.I)
_RE_ETA = re.compile(r"\(([^)]*)\)")


def _parse_ospiti(text: str):
    """'2 adulti, 2 bambini (9 e 8 anni)', '2A+1B', '2 ad. 1 bamb.' ->
    (adulti, bambini, neonati, eta_bambini, eta_incoerenti). None se non interpretabile."""
    if text is None or (isinstance(text, float) and np.isnan(text)):
        return None
    eta_match = _RE_ETA.search(text)
    body = _RE_ETA.sub(" ", text)
    found = {}
    for name, rx in (("a", _RE_ADULTI), ("b", _RE_BAMBINI), ("n", _RE_NEONATI)):
        m = rx.findall(body)
        if len(m) > 1:
            return None
        found[name] = int(m[0]) if m else 0
        body = rx.sub(" ", body)
    # Dopo aver tolto i conteggi deve restare solo "punteggiatura" (+ , e ;)
    if re.sub(r"[\s+,;&]|\be\b", "", body, flags=re.I):
        return None
    if not any(_RE.search(text) for _RE in (_RE_ADULTI, _RE_BAMBINI, _RE_NEONATI)):
        return None
    adulti, bambini, neonati = found["a"], found["b"], found["n"]
    eta, incoerenti = None, False
    if eta_match:
        eta = [int(x) for x in re.findall(r"\d+", eta_match.group(1))]
        if len(eta) != bambini:
            eta, incoerenti = None, True
    if eta:
        # i bimbi sotto ETA_NEONATO anni sono neonati (culla, non occupano posto letto)
        n_neo = sum(1 for e in eta if e < ETA_NEONATO)
        neonati += n_neo
        bambini -= n_neo
    return adulti, bambini, neonati, eta, incoerenti


def _parse_voto(value):
    """Voto in formati diversi -> (voto su 10, scala dedotta?). None se non interpretabile.
    '4/5' -> 8.0 | '8,5/10' -> 8.5 | '4 su 5' -> 8.0 | '85%' -> 8.5 | '★★★★☆' -> 8.0 | '4' -> 8.0 (dedotta)"""
    if not isinstance(value, str):
        return None
    v = value.strip().lower().replace(",", ".")
    if "★" in v or "☆" in v:
        if re.sub(r"[★☆\s]", "", v):
            return None
        piene, tot = v.count("★"), v.count("★") + v.count("☆")
        return round(piene / max(tot, 5) * 10, 1), False
    m = re.fullmatch(r"(\d+(?:\.\d+)?)\s*(?:/|su|di|out of)\s*(\d+)", v)
    if m:
        val, scala = float(m.group(1)), float(m.group(2))
        return (round(val / scala * 10, 1), False) if 0 < scala and val <= scala else None
    m = re.fullmatch(r"(\d+(?:\.\d+)?)\s*%", v)
    if m:
        val = float(m.group(1))
        return (round(val / 10, 1), False) if val <= 100 else None
    m = re.fullmatch(r"(\d+(?:\.\d+)?)\s*(?:stell[ae]|punti)?", v)
    if m:
        val = float(m.group(1))
        for scala in (5, 10, 100):
            if val <= scala:
                return round(val / scala * 10, 1), True
    return None


_RE_EMAIL = re.compile(r"[\w.+\-]+@[\w\-]+(?:\.[\w\-]+)+")
_RE_TELEFONO = re.compile(r"(?<!\w)\+?\d[\d\s./\-]{7,}\d(?!\w)")


def _mask_personal_data(text):
    """Oscura email e numeri di telefono nel testo libero (privacy)."""
    if not isinstance(text, str):
        return text
    return _RE_TELEFONO.sub("[telefono]", _RE_EMAIL.sub("[email]", text))


def _upper(series: pd.Series) -> pd.Series:
    return series.map(lambda v: v.upper() if isinstance(v, str) else v)


_RE_PERIODO = re.compile(r"dal\s+(\d{1,2})\s+([a-zà]+)\s+al\s+(\d{1,2})\s+([a-zà]+)", re.I)


def _parse_periodi(text: str):
    """'dal 5 dicembre al 31 dicembre; dal 1 gennaio al 12 aprile' -> [('12-05','12-31'), ('01-01','04-12')]"""
    out = []
    for part in str(text).split(";"):
        part = part.strip()
        if not part:
            continue
        m = _RE_PERIODO.fullmatch(part)
        if not m:
            return None
        d1, m1, d2, m2 = int(m.group(1)), MESI_IT.get(m.group(2).lower()), int(m.group(3)), MESI_IT.get(m.group(4).lower())
        try:
            date(2024, m1, d1), date(2024, m2, d2)   # 2024 è bisestile: accetta il 29 febbraio
        except (TypeError, ValueError):
            return None
        out.append((f"{m1:02d}-{d1:02d}", f"{m2:02d}-{d2:02d}"))
    return out or None


def _is_open(ids: pd.Series, dates: pd.Series, periodi: dict) -> pd.Series:
    """True se la struttura è aperta in quella data (periodi ricorrenti 'MM-GG')."""
    mmdd = dates.dt.strftime("%m-%d")
    result = pd.Series(False, index=ids.index)
    for sid, plist in periodi.items():
        sel = ids == sid
        for start, end in plist:
            inside = (mmdd >= start) & (mmdd <= end) if start <= end else (mmdd >= start) | (mmdd <= end)
            result |= sel & inside
    return result


def _strutture_targets(strutture: pd.DataFrame) -> tuple:
    """Forme accettate del nome struttura -> id_struttura (nome ufficiale, nome senza prefisso, alias)."""
    targets, canonical = {}, []
    for sid, nome in zip(strutture["id_struttura"], strutture["nome"]):
        if pd.isna(sid) or pd.isna(nome):
            continue
        targets[nome] = sid
        canonical.append(nome)
        short = re.sub(r"^(hotel|residence|chalet)\s+", "", nome, flags=re.I)
        targets.setdefault(short, sid)
    targets.update(STRUTTURE_ALIASES)
    return targets, canonical


def _periodi_dict(strutture: pd.DataFrame) -> dict:
    ok = strutture["_periodi"].notna() & strutture["id_struttura"].notna()
    return dict(zip(strutture.loc[ok, "id_struttura"], strutture.loc[ok, "_periodi"]))


def _iqr_flag(df: pd.DataFrame, col: str, group, valid: pd.Series, table: str):
    values = df[col].astype("float64")
    base = values.where(valid)
    if group:
        g = base.groupby([df[c] for c in group])
        q1, q3 = g.transform(lambda s: s.quantile(0.25)), g.transform(lambda s: s.quantile(0.75))
    else:
        q1 = pd.Series(base.quantile(0.25), index=df.index)
        q3 = pd.Series(base.quantile(0.75), index=df.index)
    low, high = q1 - IQR_K * (q3 - q1), q3 + IQR_K * (q3 - q1)
    mask = _mask(valid & ((values < low) | (values > high)))
    df[f"is_outlier_{col}"] = mask
    where = f" (per {'+'.join(group)})" if group else f" fence [{low.iloc[0]:.1f}, {high.iloc[0]:.1f}]"
    logger.info(f"[{table}] outlier IQR '{col}'{where}: {int(mask.sum())} record flaggati.")


def _to_records(df: pd.DataFrame, cols: list) -> list:
    out = df[cols].astype(object)
    out = out.where(out.notna(), None)
    return [tuple(r) for r in out.itertuples(index=False, name=None)]


def _dumps(o):
    return json.dumps(o, default=str, ensure_ascii=False)


# ---------------------------------------------------------------------------
# 1) ESTRAZIONE dai 6 database sorgente
# ---------------------------------------------------------------------------
def _open_source(src: dict):
    """PostgreSQL via psycopg2; altri motori via SQLAlchemy (pip install sqlalchemy + driver)."""
    url = src["url"]
    if url.startswith(("postgresql://", "postgres://")):
        import psycopg2
        conn = psycopg2.connect(url)
        conn.autocommit = True   # sola lettura: un errore su una tabella non blocca le successive
        return conn, "psycopg2"
    from sqlalchemy import create_engine
    return create_engine(url).connect(), "sqlalchemy"


def _fetch(conn, kind: str, sql: str):
    if kind == "psycopg2":
        with conn.cursor() as cur:
            cur.execute(sql)
            return [d[0] for d in cur.description], cur.fetchall()
    try:
        res = conn.exec_driver_sql(sql)
        return list(res.keys()), res.fetchall()
    except Exception:
        conn.rollback()
        raise


def _as_text(v):
    """Tutto come testo, come se fosse un file grezzo: nessuna conversione implicita dei tipi."""
    if v is None:
        return None
    if isinstance(v, datetime):
        return v.isoformat(sep=" ")
    if isinstance(v, date):
        return v.isoformat()
    return str(v)


def _source_sql(src: dict, name: str):
    spec = src["tabelle"].get(name, SOURCE_TABLES[name])
    if spec is None:
        return None
    if spec.lstrip().lower().startswith("select"):
        return spec
    return f'SELECT * FROM {src["schema"]}.{spec}'


def _prepare_table(df: pd.DataFrame, name: str, src: dict) -> pd.DataFrame:
    """Nomi colonna omogenei, spazi, righe vuote/note, colonne di tracciamento, id univoci, hash."""
    df.columns = df.columns.astype(str).str.strip().str.lower().str.replace(r"\s+", "_", regex=True)
    df = df.rename(columns=src["colonne"].get(name, {})).rename(columns=RENAME.get(name, {}))
    assenti = [c for c in REQUIRED_COLUMNS.get(name, []) if c not in df.columns]
    if assenti and len(df):
        raise ValueError(f"[{name}] nella fonte '{src['nome']}' mancano le colonne {assenti}. "
                         f"Colonne trovate: {list(df.columns)}. Aggiungi la rinomina in "
                         f"SOURCE_DATABASES (colonne) oppure in RENAME['{name}'] in config.py.")
    for col in EXPECTED_COLUMNS.get(name, []):
        if col not in df.columns:
            logger.warning(f"[{name}] fonte '{src['nome']}': colonna '{col}' assente, creata vuota.")
            df[col] = None
    df = df.astype(object)
    for col in df.columns:
        v = df[col].where(df[col].notna(), None)
        v = v.map(lambda x: re.sub(r"\s+", " ", x).strip() if isinstance(x, str) else x)
        df[col] = v.replace("", None)
    df.insert(0, "_riga", range(1, len(df) + 1))   # posizione del record nella fonte

    if len(df):
        data = df.drop(columns="_riga")
        empty = data.isna().all(axis=1)
        single = data.notna().sum(axis=1) == 1
        first = data.bfill(axis=1).iloc[:, 0].fillna("").astype(str)
        notes = single & first.str.contains(" ") & (first.str.len() > 30)
        for txt in first[notes]:
            logger.info(f"[{name}] fonte '{src['nome']}': nota (non è un record, rimossa): '{txt}'")
        if empty.any():
            logger.info(f"[{name}] fonte '{src['nome']}': {int(empty.sum())} righe vuote rimosse.")
        df = df.loc[~(empty | notes)].copy()

    # hash del record grezzo (prima di aggiungere fonte/prefissi): copie identiche delle
    # tabelle condivise in fonti diverse hanno lo stesso hash
    data_cols = [c for c in df.columns if c != "_riga"]
    df["_hash"] = (df[data_cols].fillna("").astype(str).agg("|".join, axis=1)
                   .map(lambda x: hashlib.sha1(x.encode("utf-8")).hexdigest())) if len(df) else None

    # tracciabilità: fonte e struttura del database da cui arriva il record
    df["fonte"] = src["nome"]
    df["_fonte_struttura"] = src["id_struttura"]
    if name in LOCAL_TABLES:
        for col, origin in ORIGIN_ID_COLUMNS.get(name, {}).items():
            df[origin] = _upper(df[col])
        # id univoci solo nel proprio database -> prefisso con la struttura
        for col in PREFIX_IDS.get(name, []):
            df[col] = df[col].map(lambda x: f"{src['id_struttura']}-{x}" if isinstance(x, str) else x)
    df["_reject_reason"] = ""
    df["dq_flags"] = ""
    return df


@task
def extract_sources():
    """Legge le tabelle da ciascuno dei database sorgente. Una fonte irraggiungibile viene
    saltata (SOURCE_ERROR_POLICY='skip') o ferma la pipeline ('fail')."""
    per_source, report = {}, {}
    for src in SOURCE_DATABASES:
        nome = src["nome"]
        try:
            conn, kind = _open_source(src)
        except Exception as e:
            report[nome] = {"stato": "ERRORE", "errore": f"connessione fallita: {e}".strip()[:500]}
            logger.error(f"Fonte '{nome}' ({src['id_struttura']}): connessione fallita "
                         f"(variabile {src['url_env']}): {str(e).strip()[:300]}")
            if SOURCE_ERROR_POLICY == "fail":
                raise
            continue
        tables, righe = {}, {}
        try:
            for name in SOURCE_TABLES:
                sql = _source_sql(src, name)
                df = None
                if sql is not None:
                    try:
                        cols, rows = _fetch(conn, kind, sql)
                        df = pd.DataFrame([[_as_text(v) for v in r] for r in rows], columns=cols, dtype=object)
                    except Exception as e:
                        if name not in OPTIONAL_SOURCES:
                            raise RuntimeError(f"tabella obbligatoria '{name}' non leggibile: {str(e).strip()[:300]}")
                        logger.info(f"[{name}] fonte '{nome}': tabella facoltativa assente, nessun record.")
                if df is None:
                    df = pd.DataFrame(columns=EXPECTED_COLUMNS.get(name, []), dtype=object)
                tables[name] = _prepare_table(df, name, src)
                righe[name] = len(tables[name])
            per_source[nome] = tables
            report[nome] = {"stato": "OK", "id_struttura": src["id_struttura"], "righe": righe}
            logger.info(f"Fonte '{nome}' ({src['id_struttura']}): estratte {sum(righe.values())} righe {righe}")
        except Exception as e:
            report[nome] = {"stato": "ERRORE", "errore": str(e)[:500]}
            logger.error(f"Fonte '{nome}' ({src['id_struttura']}) saltata: {e}")
            if SOURCE_ERROR_POLICY == "fail":
                raise
        finally:
            conn.close()

    ok = [n for n, r in report.items() if r["stato"] == "OK"]
    logger.info(f"Estrazione: {len(ok)}/{len(SOURCE_DATABASES)} fonti lette correttamente.")
    if len(ok) < MIN_SOURCES_OK:
        raise RuntimeError(f"Solo {len(ok)} fonti lette (minimo {MIN_SOURCES_OK}): {report}")
    return per_source, report


@task
def merge_sources(per_source: dict) -> dict:
    """Unisce (UNION) le tabelle di tutte le fonti in un unico insieme per tabella.
    Le tabelle condivise restano con tutte le copie: la versione da tenere si sceglie
    dopo la pulizia (check_business_rules), quando le varianti di scrittura sono già uniformate."""
    raw = {}
    for name in SOURCE_TABLES:
        parts = [t[name] for t in per_source.values() if name in t]
        df = pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()
        raw[name] = df
        per_fonte = df["fonte"].value_counts().to_dict() if len(df) else {}
        tipo = "condivisa" if name in SHARED_TABLES else "per struttura"
        logger.info(f"[{name}] unione ({tipo}): {len(df)} record da {len(parts)} fonti {per_fonte}")
    return raw


# ---------------------------------------------------------------------------
# 2) ANALISI DELLA STRUTTURA (profiling, non modifica i dati)
# ---------------------------------------------------------------------------
@task
def profile_data(raw: dict) -> dict:
    """Fotografia di ogni tabella grezza: nulli, duplicati, varianti categoriche, formati, statistiche."""
    profile = {}
    for name, df in raw.items():
        cols = [c for c in df.columns if c not in _TECH and c != "dq_flags"]
        p = {"rows": int(len(df)), "columns": len(cols)}

        nulls = df[cols].isna().sum()
        p["null_counts"] = {c: int(n) for c, n in nulls[nulls > 0].items()}
        for c, n in p["null_counts"].items():
            logger.info(f"Profilo [{name}] - nulli in '{c}': {n} ({n / max(len(df), 1):.1%})")

        p["exact_duplicates"] = int(df.duplicated(subset=cols).sum())
        if p["exact_duplicates"]:
            logger.warning(f"Profilo [{name}] - {p['exact_duplicates']} righe completamente duplicate.")
        key = NATURAL_KEY[name]
        if all(k in df.columns for k in key):
            dup_key = int(df.duplicated(subset=key).sum())
            p["duplicate_keys"] = dup_key
            if dup_key:
                logger.warning(f"Profilo [{name}] - {dup_key} chiavi {key} ripetute.")

        typed = set(DATE_COLUMNS.get(name, []) + AMOUNT_COLUMNS.get(name, []) + PCT_COLUMNS.get(name, [])
                    + INT_COLUMNS.get(name, []))

        # Formati (cifre -> 9): mostra i "pattern" di date e importi
        p["formats"] = {}
        for c in DATE_COLUMNS.get(name, []) + AMOUNT_COLUMNS.get(name, []):
            pat = df[c].dropna().astype(str).str.replace(r"\d", "9", regex=True).value_counts()
            p["formats"][c] = pat.to_dict()
            if len(pat) > 1:
                logger.warning(f"Profilo [{name}] - '{c}': formati non coerenti {pat.to_dict()}")

        # Categoriche (testo con pochi valori distinti): varianti della stessa stringa
        p["categorical_variants"], p["unique_values"] = {}, {}
        for c in cols:
            if c in typed:
                continue
            vals = df[c].dropna().unique()
            if len(vals) == 0 or len(vals) > 60:
                continue
            p["unique_values"][c] = int(len(vals))
            groups = {}
            for v in vals:
                groups.setdefault(_key(v), []).append(v)
            variants = [g for g in groups.values() if len(g) > 1]
            if variants:
                p["categorical_variants"][c] = variants
                logger.warning(f"Profilo [{name}] - '{c}': varianti della stessa stringa {variants}")
            logger.info(f"Profilo [{name}] - '{c}': {len(vals)} valori unici")

        # Statistiche numeriche (dopo un parsing "di prova")
        stats = {}
        for c in INT_COLUMNS.get(name, []) + AMOUNT_COLUMNS.get(name, []) + PCT_COLUMNS.get(name, []):
            num = pd.to_numeric(df[c].astype(str).str.replace(r"[^\d.\-]", "", regex=True), errors="coerce")
            if num.notna().any():
                stats[c] = {"min": float(num.min()), "median": float(num.median()),
                            "p99": float(num.quantile(0.99)), "max": float(num.max())}
        p["numeric_stats"] = stats
        profile[name] = p
        logger.info(f"Profilo [{name}] completato: {p['rows']} righe, {p['columns']} colonne.")
    return profile


# ---------------------------------------------------------------------------
# 3) FORMATI UNICI: date, importi, interi, ospiti, periodi di apertura
# ---------------------------------------------------------------------------
@task
def standardize_formats(tables: dict) -> dict:
    """Ogni tipo di dato in un formato unico:
       date -> AAAA-MM-GG | importi -> numero con 2 decimali (EUR) | percentuali -> 0-100
       interi -> intero | ospiti -> adulti/bambini/neonati/totale | aperture -> 'MM-GG'."""
    t = _copy(tables)

    for name, df in t.items():
        for col in DATE_COLUMNS.get(name, []):
            raw = df[col]
            df[col] = _parse_dates(raw, col, name)
            _reject(df, raw.notna() & df[col].isna(), f"formato_data_non_valido_{col}", name)
        for col in AMOUNT_COLUMNS.get(name, []) + PCT_COLUMNS.get(name, []):
            raw = df[col]
            df[col] = _parse_amount(raw, col, name)
            _reject(df, raw.notna() & df[col].isna(), f"importo_non_valido_{col}", name)
        for col in INT_COLUMNS.get(name, []):
            raw = df[col]
            df[col] = _parse_int(raw)
            _reject(df, raw.notna() & df[col].isna(), f"intero_non_valido_{col}", name)

    # --- strutture: località -> comune + provincia; categoria -> tipo + stelle; aperture -> MM-GG
    s = t["strutture"]
    loc = s["localita"].astype("string").str.extract(r"^(?P<comune>.+?)\s*\((?P<provincia>[A-Za-z]{2})\)$")
    s["comune"], s["provincia"] = loc["comune"], loc["provincia"].str.upper()
    _reject(s, s["localita"].notna() & s["comune"].isna(), "formato_localita_non_valido", "strutture")
    cat = s["categoria"].astype("string").str.extract(r"^(?P<tipo>[A-Za-z]+)(?:\s+(?P<stelle>\d)\s*stell[ae])?$")
    s["tipo_struttura"], s["stelle"] = cat["tipo"], pd.to_numeric(cat["stelle"]).astype("Int64")
    _reject(s, s["categoria"].notna() & s["tipo_struttura"].isna(), "formato_categoria_non_valido", "strutture")
    s["_periodi"] = s["periodi_apertura"].map(lambda v: _parse_periodi(v) if isinstance(v, str) else None)
    _reject(s, s["periodi_apertura"].notna() & s["_periodi"].isna(), "formato_periodi_apertura_non_valido", "strutture")
    logger.info("[strutture] periodi di apertura convertiti in formato 'MM-GG': "
                + "; ".join(f"{i}={p}" for i, p in zip(s["id_struttura"], s["_periodi"])))

    # --- prenotazioni: testo libero 'ospiti' -> colonne numeriche
    p = t["prenotazioni"]
    parsed = {v: _parse_ospiti(v) for v in p["ospiti"].dropna().unique()}
    res = p["ospiti"].map(parsed)
    bad = p["ospiti"].notna() & res.isna()
    _reject(p, bad, "formato_ospiti_non_valido", "prenotazioni")
    ok = res.notna()
    p["adulti"] = pd.array([r[0] if isinstance(r, tuple) else None for r in res], dtype="Int64")
    p["bambini"] = pd.array([r[1] if isinstance(r, tuple) else None for r in res], dtype="Int64")
    p["neonati"] = pd.array([r[2] if isinstance(r, tuple) else None for r in res], dtype="Int64")
    p["eta_bambini"] = [r[3] if isinstance(r, tuple) else None for r in res]
    incoerenti = pd.Series([bool(r[4]) if isinstance(r, tuple) else False for r in res], index=p.index)
    _flag(p, incoerenti, "eta_bambini_incoerenti", "numero di età diverso dal numero di bambini", "prenotazioni")
    p["totale_ospiti"] = p["adulti"] + p["bambini"] + p["neonati"]
    n_formati = p.loc[ok, "ospiti"].nunique()
    logger.info(f"[prenotazioni] 'ospiti': {n_formati} scritture diverse convertite in adulti/bambini/neonati/totale.")

    # --- recensioni: voto in qualsiasi scala -> scala unica 0-10
    r = t["recensioni"]
    parsed = r["voto"].map(lambda v: _parse_voto(v) if isinstance(v, str) else None)
    r["voto_originale"] = r["voto"]
    r["voto_10"] = pd.to_numeric(parsed.map(lambda x: x[0] if x else None), errors="coerce").astype("float64")
    _reject(r, r["voto"].notna() & r["voto_10"].isna(), "formato_voto_non_valido", "recensioni")
    _flag(r, parsed.map(lambda x: bool(x and x[1])).astype(bool), "scala_voto_dedotta",
          "voto senza scala: dedotta dal valore (<=5 su 5, <=10 su 10, <=100 su 100)", "recensioni")
    if len(r):
        logger.info(f"[recensioni] voto: {r['voto'].nunique()} scritture diverse convertite in scala 0-10.")

    # --- promozioni: elenco canali testuale -> lista
    pr = t["promozioni"]
    pr["_canali_raw"] = pr["canali"].map(lambda v: [c.strip() for c in v.split(",") if c.strip()] if isinstance(v, str) else None)
    return t


def _check_struttura_fonte(df: pd.DataFrame, table: str):
    """Ogni database contiene una sola struttura: id mancante -> quello della fonte;
    id diverso da quello della fonte -> quarantena."""
    miss = df["id_struttura"].isna()
    if miss.any():
        df.loc[miss, "id_struttura"] = df.loc[miss, "_fonte_struttura"]
        logger.info(f"[{table}] {int(miss.sum())} record senza struttura: assegnata quella del database di provenienza.")
    _reject(df, df["id_struttura"] != df["_fonte_struttura"], "struttura_diversa_da_quella_della_fonte", table)


# ---------------------------------------------------------------------------
# 4) VARIABILI CATEGORICHE
# ---------------------------------------------------------------------------
@task
def clean_categoricals(tables: dict) -> dict:
    """Spazi extra, maiuscole/minuscole, alias e refusi -> valore canonico.
    I valori non riconducibili a un dominio noto mandano il record in quarantena."""
    t = _copy(tables)

    def norm(name, col, canonical, aliases=None, reason=None):
        df = t[name]
        before = df[col].copy()
        df[col] = _normalize_categorical(df[col], canonical, aliases or {}, col, name)
        _reject(df, before.notna() & df[col].isna(), reason or f"valore_non_valido_{col}", name)
        logger.info(f"[{name}] categorica '{col}': {before.nunique()} valori grezzi -> {df[col].nunique()} canonici.")

    # anagrafiche
    s = t["strutture"]
    s["id_struttura"] = _upper(s["id_struttura"])
    _check_struttura_fonte(s, "strutture")
    _reject(s, ~s["id_struttura"].astype("string").str.fullmatch(r"S\d{2}", na=False) & s["id_struttura"].notna(),
            "formato_id_struttura_non_valido", "strutture")
    norm("strutture", "area", AREE)
    norm("strutture", "tipo_struttura", TIPI_STRUTTURA)

    c = t["camere"]
    c["id_struttura"] = _upper(c["id_struttura"])
    _check_struttura_fonte(c, "camere")
    tipologie = sorted(c["tipologia"].dropna().unique())  # dominio delle tipologie = anagrafica camere
    norm("camere", "tipologia", tipologie, TIPOLOGIE_ALIASES)

    canali = sorted(t["canali"]["canale"].dropna().unique())
    norm("canali", "canale", canali, CANALI_ALIASES)

    for name in ("stagionalita", "eventi"):
        norm(name, "area", AREE)
    norm("stagionalita", "stagione", STAGIONI)
    norm("stagionalita", "periodo", PERIODI_STAGIONE)

    # promozioni: codice in maiuscolo, canali -> nomi dell'anagrafica canali ("Tutti" = tutti)
    pr = t["promozioni"]
    pr["codice_promo"] = pr["codice_promo"].str.upper()
    canali_targets = {x: x for x in canali} | CANALI_ALIASES
    cmap = {_key(k): v for k, v in canali_targets.items()}

    def map_canali(lst):
        if lst is None:
            return None
        if any(_key(x) == _key(PROMO_CANALI_TUTTI) for x in lst):
            return list(canali)
        out = [cmap.get(_key(x)) for x in lst]
        return None if any(o is None for o in out) else sorted(set(out))
    pr["_canali"] = pr["_canali_raw"].map(map_canali)
    _reject(pr, pr["_canali_raw"].notna() & pr["_canali"].isna(), "canale_promo_non_riconosciuto", "promozioni")

    # struttura (nome scritto in tanti modi) -> id_struttura
    targets, canonical_names = _strutture_targets(s)
    camere_per_struttura = c.dropna(subset=["id_struttura", "tipologia"]).groupby("id_struttura")["tipologia"].apply(list).to_dict()

    def resolve_tipologia(name):
        """Tipologia: prima alias globali, poi risoluzione dentro la struttura
        (es. 'Superior' in un hotel che ha solo 'Superior vista lago')."""
        df = t[name]
        df["tipologia"] = _normalize_categorical(df["tipologia"], tipologie, TIPOLOGIE_ALIASES, "tipologia", name)
        fixed = 0
        for idx in df.index[df["id_struttura"].notna() & df["tipologia"].notna()]:
            sid, tip = df.at[idx, "id_struttura"], df.at[idx, "tipologia"]
            disponibili = camere_per_struttura.get(sid, [])
            if tip in disponibili:
                continue
            cand = [x for x in disponibili if x.lower().startswith(tip.lower())]
            if len(cand) == 1:
                df.at[idx, "tipologia"] = cand[0]
                fixed += 1
        if fixed:
            logger.warning(f"[{name}] tipologia: {fixed} valori ricondotti alla tipologia esistente nella struttura "
                           f"(es. 'Superior' -> 'Superior vista lago').")
        existing = set(map(tuple, c[["id_struttura", "tipologia"]].dropna().values.tolist()))
        pair_ok = pd.Series([(a, b) in existing for a, b in zip(df["id_struttura"], df["tipologia"])], index=df.index)
        _reject(df, df["id_struttura"].notna() & df["tipologia"].notna() & ~pair_ok,
                "tipologia_non_presente_nella_struttura", name)

    # listino: id già presente, il nome deve essere coerente con l'id
    li = t["listino"]
    li["id_struttura"] = _upper(li["id_struttura"])
    _check_struttura_fonte(li, "listino")
    id_da_nome = _map_values(li["nome_struttura"], targets, "nome_struttura", "listino", canonical_names)
    _reject(li, id_da_nome.notna() & li["id_struttura"].notna() & (id_da_nome != li["id_struttura"]),
            "id_e_nome_struttura_incoerenti", "listino")
    resolve_tipologia("listino")
    norm("listino", "stagione", STAGIONI)
    norm("listino", "periodo", PERIODI_STAGIONE)

    for name in ("prenotazioni", "occupazione"):
        df = t[name]
        df["id_struttura"] = _map_values(df["nome_struttura"], targets, "nome_struttura", name, canonical_names)
        _reject(df, df["nome_struttura"].notna() & df["id_struttura"].isna(), "struttura_non_riconosciuta", name)
        riconosciuta = df["id_struttura"].notna()
        _reject(df, riconosciuta & (df["id_struttura"] != df["_fonte_struttura"]),
                "struttura_diversa_da_quella_della_fonte", name)
        senza = df["nome_struttura"].isna()
        df.loc[senza, "id_struttura"] = df.loc[senza, "_fonte_struttura"]
        logger.info(f"[{name}] struttura: {df['nome_struttura'].nunique()} scritture -> {df['id_struttura'].nunique()} strutture.")

    # prenotazioni: tipologia, trattamento, canale, promo, stato, paese
    resolve_tipologia("prenotazioni")
    norm("prenotazioni", "codice_trattamento", list(TRATTAMENTI), TRATTAMENTI_ALIASES)
    norm("prenotazioni", "canale", canali, CANALI_ALIASES)
    norm("prenotazioni", "stato", STATI, STATI_ALIASES)
    p = t["prenotazioni"]
    p["codice_promo"] = p["codice_promo"].str.upper()
    p["id_prenotazione"] = p["id_prenotazione"].str.upper()
    p["codice_cliente"] = p["codice_cliente"].str.upper()

    # paese: tutto in ISO 3166-1 alpha-2; i valori non riconosciuti diventano "XX" (non bloccante)
    before = p["codice_paese"].copy()
    p["codice_paese"] = _normalize_categorical(before.str.upper().where(before.str.len() <= 3, before),
                                               list(PAESI), PAESI_ALIASES, "codice_paese", "prenotazioni")
    unknown = before.notna() & p["codice_paese"].isna()
    _flag(p, unknown, "paese_non_riconosciuto", f"valore impostato a '{PAESE_SCONOSCIUTO}'", "prenotazioni")
    p.loc[unknown, "codice_paese"] = PAESE_SCONOSCIUTO
    logger.info(f"[prenotazioni] categorica 'codice_paese': {before.nunique()} valori grezzi -> "
                f"{p['codice_paese'].nunique()} codici ISO.")

    # recensioni: codici in maiuscolo, piattaforma canonica, struttura ricavata dalla prenotazione
    r = t["recensioni"]
    r["id_recensione"], r["id_prenotazione"] = _upper(r["id_recensione"]), _upper(r["id_prenotazione"])
    before = r["piattaforma"].copy()
    r["piattaforma"] = _normalize_categorical(before, PIATTAFORME, PIATTAFORME_ALIASES, "piattaforma", "recensioni")
    altro = before.notna() & r["piattaforma"].isna()
    _flag(r, altro, "piattaforma_non_riconosciuta", "valore impostato a 'Altro'", "recensioni")
    r.loc[altro, "piattaforma"] = "Altro"
    # testo libero: email e telefoni oscurati (dati personali)
    for col in ("titolo", "testo"):
        masked = r[col].map(_mask_personal_data)
        _flag(r, r[col].notna() & (masked != r[col]), f"dati_personali_oscurati_{col}",
              "email o numeri di telefono sostituiti con [email]/[telefono]", "recensioni")
        r[col] = masked
    return t


# ---------------------------------------------------------------------------
# 5) VALORI MANCANTI
# ---------------------------------------------------------------------------
@task
def handle_missing_values(tables: dict) -> dict:
    """Strategia per colonna:
       - campi critici mancanti -> quarantena
       - conteggi mancanti -> 0
       - paese mancante -> 'XX' (sconosciuto)
       - ospiti presenti mancanti -> stima da camere occupate x ospiti medi per camera della struttura
       - promo/note/data cancellazione/supplementi residence -> NULL (assenza = informazione vera)"""
    t = _copy(tables)

    for name, cols in ZERO_FILL_COLUMNS.items():
        df = t[name]
        for col in cols:
            n = int(df[col].isna().sum())
            if n:
                df[col] = df[col].fillna(0)
                logger.warning(f"[{name}] mancanti '{col}': {n} valori riempiti con 0.")

    p = t["prenotazioni"]
    n = int(p["codice_paese"].isna().sum())
    if n:
        p["codice_paese"] = p["codice_paese"].fillna(PAESE_SCONOSCIUTO)
        logger.warning(f"[prenotazioni] mancanti 'codice_paese': {n} valori impostati a '{PAESE_SCONOSCIUTO}' (sconosciuto).")
    for col, why in [("codice_promo", "nessuna promozione applicata"), ("note", "nessuna richiesta"),
                     ("data_cancellazione", "prenotazione non cancellata")]:
        logger.info(f"[prenotazioni] '{col}': {int(p[col].isna().sum())} NULL mantenuti ({why}).")
    # notti mancanti: si ricavano dalle date
    miss_n = p["notti"].isna() & p["check_in"].notna() & p["check_out"].notna()
    if miss_n.any():
        p.loc[miss_n, "notti"] = (p.loc[miss_n, "check_out"] - p.loc[miss_n, "check_in"]).dt.days
        logger.warning(f"[prenotazioni] mancanti 'notti': {int(miss_n.sum())} ricavate da check_out - check_in.")

    # listino: i supplementi pensione non esistono nei residence (niente ristorante) -> NULL legittimo
    li, st = t["listino"], t["strutture"]
    tipo = li["id_struttura"].map(dict(zip(st["id_struttura"], st["tipo_struttura"])))
    for col in ["suppl_mezza_pensione_eur", "suppl_pensione_completa_eur"]:
        miss = li[col].isna()
        logger.info(f"[listino] '{col}': {int((miss & (tipo == 'Residence')).sum())} NULL mantenuti (residence: non previsto).")
        _reject(li, miss & (tipo != "Residence"), f"mancante_{col}", "listino")
    # periodo (inverno/estate) mancante: lo si riprende dalla stagionalità in fase di regole

    # occupazione: ospiti presenti mancanti -> stima
    o = t["occupazione"]
    miss = o["ospiti_presenti"].isna()
    if miss.any():
        has = ~miss & (o["camere_occupate"] > 0) & (o["ospiti_presenti"] > 0)
        ratio = (o.loc[has, "ospiti_presenti"] / o.loc[has, "camere_occupate"]).astype("float64")
        med = ratio.groupby(o.loc[has, "id_struttura"]).median()
        stima = (o["camere_occupate"].astype("float64") * o["id_struttura"].map(med)).round()
        o["ospiti_presenti_stimati"] = miss & stima.notna()
        o.loc[o["ospiti_presenti_stimati"], "ospiti_presenti"] = stima[o["ospiti_presenti_stimati"]].astype("int64")
        logger.warning(f"[occupazione] mancanti 'ospiti_presenti': {int(o['ospiti_presenti_stimati'].sum())} valori "
                       f"stimati (camere occupate x ospiti medi per camera della struttura: "
                       f"{ {k: round(v, 2) for k, v in med.items()} }); marcati con ospiti_presenti_stimati = TRUE.")
    else:
        o["ospiti_presenti_stimati"] = False

    # recensioni: piattaforma mancante -> "Non indicata"; senza voto e senza testo non è una recensione
    r = t["recensioni"]
    n = int(r["piattaforma"].isna().sum())
    if n:
        r["piattaforma"] = r["piattaforma"].fillna("Non indicata")
        logger.warning(f"[recensioni] mancanti 'piattaforma': {n} valori impostati a 'Non indicata'.")
    _reject(r, r["voto_10"].isna() & r["testo"].isna() & r["voto"].isna(), "recensione_senza_voto_e_senza_testo",
            "recensioni")
    if len(r):
        logger.info(f"[recensioni] {int((r['voto_10'].isna() & r['testo'].notna()).sum())} recensioni solo testo "
                    f"(voto NULL), {int((r['testo'].isna() & r['voto_10'].notna()).sum())} solo voto (testo NULL).")

    # campi critici
    for name, cols in CRITICAL_COLUMNS.items():
        df = t[name]
        for col in cols:
            # se il valore c'era ma era illeggibile, il motivo è già stato registrato
            gia = df["_reject_reason"].str.contains(rf"_{col}(;|$)", regex=True)
            _reject(df, df[col].isna() & ~gia, f"mancante_{col}", name)
    return t


# ---------------------------------------------------------------------------
# 6) COLONNE NUMERICHE: ERRORI vs OUTLIER
# ---------------------------------------------------------------------------
@task
def handle_numeric_outliers(tables: dict) -> dict:
    """Due livelli:
      - limiti rigidi (valori impossibili: importi negativi, 40 adulti...) -> quarantena
      - outlier statistici IQR (estremi ma plausibili) -> solo flag is_outlier_*
    I valori plausibili non vengono mai modificati né cancellati."""
    t = _copy(tables)

    # campi derivati
    p = t["prenotazioni"]
    # check-in e check-out invertiti (la differenza coincide con le notti dichiarate): si scambiano
    inv = (p["check_out"] < p["check_in"]) & ((p["check_in"] - p["check_out"]).dt.days == p["notti"])
    if _flag(p, inv, "check_in_check_out_invertiti", "date di arrivo e partenza scambiate: corrette", "prenotazioni"):
        p.loc[inv, ["check_in", "check_out"]] = p.loc[inv, ["check_out", "check_in"]].values
    notti_date = (p["check_out"] - p["check_in"]).dt.days.astype("Int64")
    diverse = p["notti"].notna() & notti_date.notna() & (p["notti"] != notti_date) & (notti_date > 0)
    _flag(p, diverse, "notti_ricalcolate", "notti dichiarate diverse da check_out - check_in: vale il calcolo dalle date",
          "prenotazioni")
    p.loc[diverse, "notti"] = notti_date[diverse]
    p["lead_time_giorni"] = (p["check_in"] - p["data_prenotazione"]).dt.days.astype("Int64")
    notti_f = p["notti"].astype("float64")
    p["prezzo_medio_notte_eur"] = (p["importo_totale_eur"] / notti_f.where(notti_f > 0)).round(2)

    o = t["occupazione"]
    disp = o["camere_disponibili"].astype("float64")
    occ = o["camere_occupate"].astype("float64")
    o["tasso_occupazione_pct"] = (occ / disp.where(disp > 0) * 100).round(2)
    o["adr_eur"] = (o["ricavo_camere_eur"] / occ.where(occ > 0)).round(2)

    # limiti rigidi
    for name, limits in HARD_LIMITS.items():
        df = t[name]
        for col, (low, high) in limits.items():
            v = df[col].astype("float64")
            _reject(df, (v < low) | (v > high), f"{col}_fuori_limiti_[{low},{high}]", name)

    # outlier statistici, calcolati solo sulle righe non scartate
    for name, specs in OUTLIER_COLUMNS.items():
        df = t[name]
        valid = (df["_reject_reason"] == "") & df[[c for c, _ in specs]].notna().all(axis=1)
        for col, group in specs:
            _iqr_flag(df, col, group, valid, name)
    return t


# ---------------------------------------------------------------------------
# 7) REGOLE LOGICHE DI BUSINESS
# ---------------------------------------------------------------------------
@task
def check_business_rules(tables: dict) -> dict:
    """Regole di coerenza. BLOCCANTI = quarantena; NON BLOCCANTI = flag in dq_flags."""
    t = _copy(tables)
    # tabelle condivise: una sola versione per chiave (prima di qualsiasi altro controllo)
    for name in ("canali", "eventi", "promozioni"):
        t[name] = _resolve_shared(t[name], name)
    st, cam = t["strutture"], t["camere"]
    periodi = _periodi_dict(st)
    area_di = dict(zip(st["id_struttura"], st["area"]))

    # ---------------- strutture / camere ----------------
    somma = cam.groupby("id_struttura")["n_unita"].sum()
    _flag(st, st["unita_totali"] != st["id_struttura"].map(somma), "unita_totali_diverse_da_somma_camere",
          "unità totali diverse dalla somma delle camere in anagrafica", "strutture")

    # ---------------- stagionalità / eventi / listino ----------------
    for name in ("stagionalita", "eventi", "listino"):
        df = t[name]
        _reject(df, df["data_fine"] < df["data_inizio"], "data_fine_precedente_a_data_inizio", name)

    sg = t["stagionalita"]
    sg["id_stagionalita"] = sg["area"].astype(str) + "-" + sg["data_inizio"].dt.strftime("%Y-%m-%d")
    sg = t["stagionalita"] = _resolve_shared(sg, "stagionalita")
    sg_sorted = sg[sg["_reject_reason"] == ""].sort_values(["area", "data_inizio"])
    overlap = sg_sorted["data_inizio"] <= sg_sorted.groupby("area")["data_fine"].shift()
    _flag(sg, overlap.reindex(sg.index), "periodo_sovrapposto", "si sovrappone al periodo precedente", "stagionalita")

    li = t["listino"]
    li_sorted = li.sort_values(["id_struttura", "tipologia", "data_inizio"])
    overlap = li_sorted["data_inizio"] <= li_sorted.groupby(["id_struttura", "tipologia"])["data_fine"].shift()
    _reject(li, overlap.reindex(li.index), "validita_sovrapposta_a_altra_tariffa", "listino")
    # collegamento alla stagionalità della stessa area (chiave esterna id_stagionalita)
    li["_area"] = li["id_struttura"].map(area_di)
    li["id_stagionalita"] = None
    for r in sg.dropna(subset=["area", "data_inizio", "data_fine"]).itertuples():
        inside = (li["_area"] == r.area) & (li["data_inizio"] >= r.data_inizio) & (li["data_fine"] <= r.data_fine)
        li.loc[inside & li["id_stagionalita"].isna(), "id_stagionalita"] = r.id_stagionalita
    _flag(li, li["id_stagionalita"].isna(), "stagionalita_non_trovata",
          "periodo di validità non contenuto in un periodo di stagionalità dell'area", "listino")
    sg_stag = li["id_stagionalita"].map(dict(zip(sg["id_stagionalita"], sg["stagione"])))
    sg_per = li["id_stagionalita"].map(dict(zip(sg["id_stagionalita"], sg["periodo"])))
    _flag(li, sg_stag.notna() & (sg_stag != li["stagione"]), "stagione_diversa_da_stagionalita",
          "stagione del listino diversa da quella del calendario", "listino")
    fill = li["periodo"].isna() & sg_per.notna()
    if fill.any():
        li.loc[fill, "periodo"] = sg_per[fill]
        logger.info(f"[listino] 'periodo': {int(fill.sum())} valori ripresi dalla stagionalità collegata.")
    # la tariffa deve crescere con la stagione (bassa < media < alta < altissima) a parità di camera e anno
    rank = li["stagione"].map({s: i for i, s in enumerate(STAGIONI)})
    grp = [li["id_struttura"], li["tipologia"], li["data_inizio"].dt.year, li["periodo"].fillna("-")]
    incoerente = pd.Series(False, index=li.index)
    for _, g in li.assign(_rank=rank).groupby(grp):
        for idx, row in g.iterrows():
            lower = g[g["_rank"] < row["_rank"]]
            if (lower["tariffa_notte_bb_eur"] > row["tariffa_notte_bb_eur"]).any():
                incoerente[idx] = True
    _flag(li, incoerente, "tariffa_non_coerente_con_stagione",
          "tariffa inferiore a quella di una stagione più bassa", "listino")

    # ---------------- prenotazioni ----------------
    p = t["prenotazioni"]
    # bloccanti
    _reject(p, p["totale_ospiti"] == 0, "zero_ospiti", "prenotazioni")
    _reject(p, (p["adulti"] == 0) & (p["totale_ospiti"] > 0), "nessun_adulto", "prenotazioni")
    _reject(p, p["check_out"] <= p["check_in"], "check_out_non_successivo_al_check_in", "prenotazioni")
    _reject(p, p["data_prenotazione"] > p["check_in"], "prenotazione_successiva_al_check_in", "prenotazioni")
    _reject(p, p["stato"].isin(["confermata", "no-show"]) & p["data_cancellazione"].notna(),
            "stato_non_cancellato_ma_con_data_cancellazione", "prenotazioni")
    _reject(p, p["data_cancellazione"] < p["data_prenotazione"], "cancellazione_precedente_alla_prenotazione",
            "prenotazioni")
    # stesso id con contenuto diverso: non si sa quale sia giusto -> entrambi in quarantena
    conflitto = p.groupby("id_prenotazione")["_hash"].transform("nunique") > 1
    _reject(p, conflitto, "id_duplicato_con_dati_diversi", "prenotazioni")

    # non bloccanti
    _flag(p, (p["stato"] == "cancellata") & p["data_cancellazione"].isna(), "cancellata_senza_data_cancellazione",
          "stato cancellata ma data di cancellazione assente", "prenotazioni")
    _flag(p, p["data_cancellazione"] > p["check_in"], "cancellazione_dopo_check_in",
          "cancellazione successiva al giorno di arrivo", "prenotazioni")
    _flag(p, (p["importo_totale_eur"] == 0) & (p["stato"] == "confermata"), "importo_zero_su_confermata",
          "prenotazione confermata con importo 0", "prenotazioni")
    capienza = pd.Series(list(zip(p["id_struttura"], p["tipologia"])), index=p.index).map(
        {(a, b): v for a, b, v in cam[["id_struttura", "tipologia", "capienza_max"]].itertuples(index=False)})
    _flag(p, (p["adulti"] + p["bambini"]) > capienza, "ospiti_oltre_capienza_camera",
          "adulti + bambini oltre la capienza massima della camera (neonati esclusi)", "prenotazioni")

    # ogni notte del soggiorno deve cadere in un periodo di apertura della struttura
    ok = (p["_reject_reason"] == "") & p["check_in"].notna() & (p["notti"].fillna(0) > 0)
    stay = p.loc[ok, ["id_struttura", "check_in", "notti"]]
    nights = stay.loc[stay.index.repeat(stay["notti"].astype(int))]
    nights_dates = nights["check_in"] + pd.to_timedelta(nights.groupby(level=0).cumcount(), unit="D")
    aperta = _is_open(nights["id_struttura"], nights_dates, periodi)
    chiusa = (~aperta).groupby(level=0).any().reindex(p.index, fill_value=False)
    _flag(p, chiusa, "soggiorno_in_periodo_di_chiusura", "almeno una notte fuori dal periodo di apertura", "prenotazioni")

    # promozioni: canale ammesso e condizioni dell'offerta
    promo_canali = {(cp, ch) for cp, lst in zip(t["promozioni"]["codice_promo"], t["promozioni"]["_canali"])
                    if lst for ch in lst}
    con_promo = p["codice_promo"].notna()
    ammesso = pd.Series([(a, b) in promo_canali for a, b in zip(p["codice_promo"], p["canale"])], index=p.index)
    _flag(p, con_promo & ~ammesso, "promo_su_canale_non_ammesso", "promozione non prevista per il canale", "prenotazioni")
    stagione_arrivo = _stagione_di(p["id_struttura"].map(area_di), p["check_in"], sg)
    periodo_arrivo = _stagione_di(p["id_struttura"].map(area_di), p["check_in"], sg, col="periodo")
    for code, r in PROMO_RULES.items():
        sel = p["codice_promo"] == code
        bad = pd.Series(False, index=p.index)
        if "min_lead" in r:
            bad |= p["lead_time_giorni"] < r["min_lead"]
        if "max_lead" in r:
            bad |= p["lead_time_giorni"] > r["max_lead"]
        if "min_notti" in r:
            bad |= p["notti"] < r["min_notti"]
        if "area" in r:
            bad |= p["id_struttura"].map(area_di) != r["area"]
        # stagione/periodo si controllano solo se la data è coperta dal calendario stagionalità
        if "stagioni" in r:
            bad |= stagione_arrivo.notna() & ~stagione_arrivo.isin(r["stagioni"])
        if "periodo" in r:
            bad |= stagione_arrivo.notna() & (periodo_arrivo != r["periodo"])
        if "giorni_arrivo" in r:
            bad |= ~p["check_in"].dt.dayofweek.isin(r["giorni_arrivo"])
        _flag(p, sel & bad, f"condizioni_promo_{code}_non_rispettate", f"requisiti della promo {code}", "prenotazioni")

    # ---------------- occupazione ----------------
    o = t["occupazione"]
    unita = o["id_struttura"].map(dict(zip(st["id_struttura"], st["unita_totali"])))
    cap_tot = (cam["n_unita"] * cam["capienza_max"]).groupby(cam["id_struttura"]).sum()
    _reject(o, o["camere_occupate"] > o["camere_disponibili"], "camere_occupate_oltre_disponibili", "occupazione")
    _reject(o, (o["camere_disponibili"] + o["camere_fuori_servizio"]) > unita, "camere_oltre_unita_struttura",
            "occupazione")
    conflitto = o.groupby(["id_struttura", "data"])["_hash"].transform("nunique") > 1
    _reject(o, conflitto, "giorno_duplicato_con_dati_diversi", "occupazione")
    _flag(o, ~o["ospiti_presenti_stimati"] & (o["ospiti_presenti"] < o["camere_occupate"]), "ospiti_meno_delle_camere",
          "meno ospiti che camere occupate", "occupazione")
    _flag(o, o["ospiti_presenti"] > o["id_struttura"].map(cap_tot), "ospiti_oltre_capienza_struttura",
          "ospiti oltre i posti letto della struttura", "occupazione")
    _flag(o, (o["camere_occupate"] > 0) & (o["ricavo_camere_eur"] == 0), "ricavo_zero_con_camere_occupate",
          "camere occupate ma ricavo nullo", "occupazione")
    _flag(o, (o["camere_occupate"] == 0) & (o["ricavo_camere_eur"] > 0), "ricavo_senza_camere_occupate",
          "ricavo positivo senza camere occupate", "occupazione")
    _flag(o, (o["arrivi"] > o["camere_disponibili"]) | (o["partenze"] > o["camere_disponibili"]),
          "arrivi_o_partenze_oltre_disponibili", "più arrivi/partenze che camere", "occupazione")
    aperta = _is_open(o["id_struttura"], o["data"], periodi) & o["data"].notna()
    _flag(o, ~aperta & (o["camere_occupate"] > 0), "attivita_in_periodo_di_chiusura",
          "camere occupate in un giorno di chiusura", "occupazione")
    _flag(o, aperta & (o["camere_disponibili"] == 0), "nessuna_camera_in_periodo_di_apertura",
          "0 camere disponibili in un giorno di apertura", "occupazione")
    # ---------------- recensioni ----------------
    r = t["recensioni"]
    pren = p.drop_duplicates("id_prenotazione").set_index("id_prenotazione")
    stato = r["id_prenotazione"].map(pren["stato"])
    ci, co = r["id_prenotazione"].map(pren["check_in"]), r["id_prenotazione"].map(pren["check_out"])
    r["giorni_dopo_check_out"] = (r["data_recensione"] - pd.to_datetime(co)).dt.days.astype("Int64")
    # bloccanti
    _reject(r, stato.isin(["cancellata", "no-show"]), "recensione_su_soggiorno_non_avvenuto", "recensioni")
    _reject(r, r["data_recensione"] < pd.to_datetime(ci), "recensione_precedente_al_check_in", "recensioni")
    _reject(r, r["data_recensione"] > pd.Timestamp.today().normalize(), "data_recensione_futura", "recensioni")
    conflitto = r.groupby("id_recensione")["_hash"].transform("nunique") > 1
    _reject(r, conflitto, "id_duplicato_con_dati_diversi", "recensioni")
    # non bloccanti
    _flag(r, r["giorni_dopo_check_out"] < 0, "recensione_durante_il_soggiorno", "scritta prima del check-out",
          "recensioni")
    _flag(r, r["giorni_dopo_check_out"] > GIORNI_MAX_RECENSIONE, "recensione_molto_tardiva",
          f"oltre {GIORNI_MAX_RECENSIONE} giorni dal check-out", "recensioni")
    piu = r.drop_duplicates("_hash").groupby(["id_prenotazione", "piattaforma"])["id_recensione"].transform("nunique")
    _flag(r, (piu.reindex(r.index) > 1), "piu_recensioni_stessa_prenotazione",
          "più recensioni per la stessa prenotazione e piattaforma", "recensioni")
    _flag(r, r["testo"].map(lambda v: isinstance(v, str) and len(v.split()) < 3), "testo_molto_breve",
          "meno di 3 parole", "recensioni")
    return t


def _resolve_shared(df: pd.DataFrame, table: str) -> pd.DataFrame:
    """Tabelle condivise: ogni fonte ne ha una copia. Per ogni chiave si tiene la versione
    presente nel maggior numero di fonti (a parità, la prima fonte in SOURCE_DATABASES).
    Le copie identiche si eliminano; le versioni diverse vanno in quarantena."""
    _, cols, pk = TABLES[table]
    compare = [c for c in cols if c not in pk and c not in ("dq_flags", "fonte")]
    if table == "promozioni":
        compare.append("_canali")

    def norm(v):
        if isinstance(v, (list, tuple)):
            return tuple(v)
        return None if pd.isna(v) else v

    valid = df["_reject_reason"] == ""
    sig = pd.Series([tuple(norm(v) for v in row) for row in df[compare].itertuples(index=False, name=None)],
                    index=df.index)
    keys = df[pk].apply(tuple, axis=1)
    drop, minority = [], pd.Series(False, index=df.index)
    for key, idx in keys[valid].groupby(keys[valid]).groups.items():
        versions = sig[idx]
        if versions.nunique() > 1:
            counts = versions.value_counts(sort=False)
            winner = counts.idxmax()   # a parità vince la prima comparsa (ordine delle fonti)
            losers = idx[versions != winner]
            minority[losers] = True
            logger.warning(f"[{table}] chiave {key}: versioni diverse tra le fonti. Tenuta quella di "
                           f"{sorted(df.loc[idx[versions == winner], 'fonte'].unique())}, scartata quella di "
                           f"{sorted(df.loc[losers, 'fonte'].unique())}.")
        keep = idx[versions == versions.value_counts(sort=False).idxmax()]
        drop.extend(keep[1:])   # copie identiche: ne basta una
    _reject(df, minority, "versione_diversa_tra_fonti_scartata", table)
    if drop:
        logger.info(f"[{table}] {len(drop)} copie identiche provenienti da fonti diverse unificate "
                    f"({int(valid.sum()) - len(drop) - int(minority.sum())} record unici).")
    return df.drop(index=drop)


def _stagione_di(area: pd.Series, dates: pd.Series, sg: pd.DataFrame, col: str = "stagione") -> pd.Series:
    """Stagione (o periodo inverno/estate) del calendario per area e data."""
    out = pd.Series(None, index=dates.index, dtype=object)
    valid = sg.dropna(subset=["area", "data_inizio", "data_fine"])
    for r in valid.itertuples():
        sel = (area == r.area) & (dates >= r.data_inizio) & (dates <= r.data_fine)
        out[sel] = getattr(r, col)
    return out


# ---------------------------------------------------------------------------
# 8) QUARANTENA + TABELLE DERIVATE
# ---------------------------------------------------------------------------
@task
def quarantine_rejected(tables: dict, raw: dict):
    """Separa record validi e scartati. Gli scartati NON si perdono: finiscono (con motivo e
    record grezzo originale) nella tabella 'scarti'. Controlla anche le chiavi esterne:
    un figlio il cui padre è stato scartato viene scartato a sua volta."""
    t = _copy(tables)

    # tabelle di dominio (da config) e tabelle derivate da colonne "lista"
    t["aree"] = pd.DataFrame({"area": AREE, "_reject_reason": "", "dq_flags": ""})
    t["paesi"] = pd.DataFrame({"codice_paese": list(PAESI), "nome": list(PAESI.values()),
                               "_reject_reason": "", "dq_flags": ""})
    t["trattamenti"] = pd.DataFrame({"codice_trattamento": list(TRATTAMENTI), "descrizione": list(TRATTAMENTI.values()),
                                     "_reject_reason": "", "dq_flags": ""})

    clean, rejected_parts, reasons, ratios = {}, [], {}, {}
    for name in LOAD_ORDER:
        if name == "periodi_apertura":
            s = clean["strutture"]
            rows = [(sid, a, b) for sid, plist in zip(s["id_struttura"], s["_periodi"]) for a, b in plist]
            clean[name] = pd.DataFrame(rows, columns=["id_struttura", "inizio_mm_gg", "fine_mm_gg"])
            continue
        if name == "promozioni_canali":
            pr = clean["promozioni"]
            rows = [(cp, ch) for cp, lst in zip(pr["codice_promo"], pr["_canali"]) for ch in lst]
            df = pd.DataFrame(rows, columns=["codice_promo", "canale"])
            clean[name] = df[df["canale"].isin(clean["canali"]["canale"])]
            continue

        df = t[name]
        # chiavi esterne verso tabelle già pulite
        for child, ccols, parent, pcols in FOREIGN_KEYS:
            if child != name:
                continue
            parent_keys = set(map(tuple, clean[parent][pcols].values.tolist()))
            vals = df[ccols]
            present = vals.notna().all(axis=1)
            found = pd.Series([tuple(v) in parent_keys for v in vals.values.tolist()], index=df.index)
            _reject(df, present & ~found & (df["_reject_reason"] == ""), f"chiave_esterna_{parent}_non_trovata", name)

        bad = df["_reject_reason"] != ""
        if name in raw and bad.any():
            # le versioni scartate delle tabelle condivise sono un esito previsto dell'unione,
            # non un segnale di file corrotto: non contano per la soglia MAX_REJECT_RATIO
            solo_conflitto = df["_reject_reason"] == "versione_diversa_tra_fonti_scartata"
            ratios[name] = float((bad & ~solo_conflitto).mean()) if len(df) else 0.0
            r = df.loc[bad, "_reject_reason"].str.split(";").explode().value_counts().to_dict()
            if r:
                reasons[name] = r
            src = raw[name].loc[df.index[bad]]
            keycols = [k for k in NATURAL_KEY[name] if k in src.columns]
            rejected_parts.append(pd.DataFrame({
                "tabella": name,
                "fonte": src["fonte"].values,
                "chiave": src[keycols].fillna("").astype(str).agg("|".join, axis=1).values,
                "riga_sorgente": src["_riga"].values,
                "motivo": df.loc[bad, "_reject_reason"].values,
                "record_hash": src["_hash"].values,
                "raw_record": src.drop(columns=[c for c in _TECH + ["dq_flags"] if c in src.columns])
                                 .apply(lambda r: r.dropna().to_dict(), axis=1).values,
            }))
            logger.info(f"[{name}] quarantena: {int(bad.sum())} scartati ({ratios[name]:.2%}), "
                        f"{int((~bad).sum())} validi. Motivi: {r}")

        elif name in raw:
            ratios[name] = 0.0
        out = df.loc[~bad].copy()
        out["dq_flags"] = out["dq_flags"].replace("", None)
        # duplicati esatti (stesso record ripetuto): si tiene il primo
        pk = TABLES[name][2]
        n_dup = int(out.duplicated(subset=pk).sum())
        if n_dup:
            logger.warning(f"[{name}] rimosse {n_dup} righe duplicate (stessa chiave {pk}, stesso contenuto).")
            out = out.drop_duplicates(subset=pk)
        clean[name] = out

    rejected = pd.concat(rejected_parts, ignore_index=True) if rejected_parts else pd.DataFrame(
        columns=["tabella", "fonte", "chiave", "riga_sorgente", "motivo", "record_hash", "raw_record"])

    troppi = {k: v for k, v in ratios.items() if v > MAX_REJECT_RATIO.get(k, MAX_REJECT_RATIO["default"])}
    if troppi:
        raise ValueError(f"Troppi record scartati {({k: f'{v:.1%}' for k, v in troppi.items()})}: "
                         f"controllare i file sorgente. Motivi: { {k: reasons.get(k) for k in troppi} }")
    return clean, rejected, reasons


# ---------------------------------------------------------------------------
# 9) VALIDAZIONE FINALE
# ---------------------------------------------------------------------------
@task
def validate_data(clean: dict) -> dict:
    """Ultimo controllo prima del DB: schema, chiavi primarie/esterne, obbligatorietà, domini."""
    errors = []
    for name in LOAD_ORDER:
        df = clean.get(name)
        _, cols, pk = TABLES[name]
        if df is None or df.empty:
            if name in OPTIONAL_SOURCES:
                logger.info(f"[{name}] tabella facoltativa vuota: nessun record da caricare.")
            else:
                errors.append(f"[{name}] tabella vuota: nessun record da caricare.")
            continue
        missing = [c for c in cols if c not in df.columns]
        if missing:
            errors.append(f"[{name}] colonne mancanti rispetto allo schema: {missing}")
            continue
        n_dup = int(df.duplicated(subset=pk).sum())
        if n_dup:
            errors.append(f"[{name}] {n_dup} chiavi primarie {pk} duplicate.")
        for col in cols:
            if col in NULLABLE.get(name, []) or col.startswith("is_outlier_"):
                continue
            n = int(df[col].isna().sum())
            if n:
                errors.append(f"[{name}] {n} valori nulli nel campo obbligatorio '{col}'.")

    for child, ccols, parent, pcols in FOREIGN_KEYS:
        c, pa = clean[child], clean[parent]
        keys = set(map(tuple, pa[pcols].values.tolist()))
        vals = c[ccols].dropna()
        n = sum(tuple(v) not in keys for v in vals.values.tolist())
        if n:
            errors.append(f"[{child}] {n} valori di {ccols} senza corrispondenza in {parent}.")

    p, o = clean["prenotazioni"], clean["occupazione"]
    checks = [
        ("prenotazioni", ~p["stato"].isin(STATI), "stato fuori dominio"),
        ("prenotazioni", p["totale_ospiti"] <= 0, "prenotazioni con 0 ospiti"),
        ("prenotazioni", p["check_out"] <= p["check_in"], "check_out non successivo al check_in"),
        ("prenotazioni", (p["stato"] != "cancellata") & p["data_cancellazione"].notna(),
         "prenotazioni non cancellate con data di cancellazione"),
        ("prenotazioni", p["importo_totale_eur"] < 0, "importi negativi"),
        ("occupazione", o["camere_occupate"] > o["camere_disponibili"], "camere occupate oltre le disponibili"),
    ]
    for name, mask, msg in checks:
        n = int(_mask(mask).sum())
        if n:
            errors.append(f"[{name}] {n} record: {msg}.")

    if errors:
        msg = "Validazione dati fallita:\n" + "\n".join(f"- {e}" for e in errors)
        logger.error(msg)
        raise ValueError(msg)
    logger.info("Validazione completata: " + ", ".join(f"{k}={len(clean[k])}" for k in LOAD_ORDER)
                + " record, nessun errore bloccante.")
    return clean


# ---------------------------------------------------------------------------
# 10) CARICAMENTO SU POSTGRESQL
# ---------------------------------------------------------------------------
@task
def load_data(clean: dict, rejected: pd.DataFrame) -> dict:
    """Crea schema e tabelle se mancano e carica ogni tabella (nell'ordine delle chiavi esterne)
    con INSERT ... ON CONFLICT DO UPDATE: rilanciare la pipeline non crea duplicati e aggiorna
    i record modificati. Tutto in un'unica transazione: o si carica tutto o niente."""
    result = {}
    conn = get_connection()
    try:
        with conn, conn.cursor() as cur:
            cur.execute(DDL)
            for name in LOAD_ORDER:
                table, cols, pk = TABLES[name]
                out = clean[name][cols].copy()
                for col in DATE_COLUMNS.get(name, []):
                    if col in out.columns:
                        out[col] = out[col].dt.date
                records = _to_records(out, cols)
                if not records:
                    result[name] = {"inserted": 0, "updated": 0, "unchanged": 0}
                    continue
                updatable = [c for c in cols if c not in pk]
                if updatable:
                    set_sql = ", ".join(f"{c} = EXCLUDED.{c}" for c in updatable)
                    if name in ("prenotazioni", "occupazione", "recensioni"):
                        set_sql += ", caricato_il = now()"
                    conflict = f"DO UPDATE SET {set_sql}"
                else:
                    conflict = "DO NOTHING"
                sql = (f"INSERT INTO {DB_SCHEMA}.{table} ({', '.join(cols)}) VALUES %s "
                       f"ON CONFLICT ({', '.join(pk)}) {conflict} RETURNING (xmax = 0)")
                flags = [r[0] for r in execute_values(cur, sql, records, page_size=5000, fetch=True)]
                ins = sum(flags)
                result[name] = {"inserted": ins, "updated": len(flags) - ins,
                                "unchanged": len(records) - len(flags)}
                logger.info(f"[{name}] -> {DB_SCHEMA}.{table}: {ins} inseriti, {len(flags) - ins} aggiornati.")

            saved = 0
            if len(rejected):
                rows = [(r.tabella, r.fonte, r.chiave, int(r.riga_sorgente), r.motivo, r.record_hash,
                         Json(r.raw_record, dumps=_dumps)) for r in rejected.itertuples()]
                saved = len(execute_values(
                    cur,
                    f"INSERT INTO {DB_SCHEMA}.{TABLE_REJECTED} (tabella, fonte, chiave, riga_sorgente, motivo, record_hash, raw_record) "
                    f"VALUES %s ON CONFLICT (tabella, fonte, record_hash, motivo) DO NOTHING RETURNING id",
                    rows, page_size=1000, fetch=True))
            result["scarti_nuovi"] = saved
            logger.info(f"{saved} nuovi record in {DB_SCHEMA}.{TABLE_REJECTED}.")
    finally:
        conn.close()
    return result


# ---------------------------------------------------------------------------
# 11) MONITORAGGIO
# ---------------------------------------------------------------------------
@task
def log_execution(status: str, extracted: int = 0, rejected: int = 0, inserted: int = 0,
                  updated: int = 0, sources_ok: int = 0, sources_failed: int = 0,
                  errors: str = "", details: dict | None = None):
    """Registra il riepilogo dell'esecuzione sulla tabella pipeline_runs."""
    conn = get_connection()
    try:
        with conn, conn.cursor() as cur:
            cur.execute(DDL)
            cur.execute(
                f"INSERT INTO {DB_SCHEMA}.{TABLE_RUNS} "
                f"(status, records_extracted, records_rejected, records_inserted, records_updated, "
                f"sources_ok, sources_failed, errors, details) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)",
                (status, extracted, rejected, inserted, updated, sources_ok, sources_failed, errors,
                 Json(details or {}, dumps=_dumps)),
            )
    finally:
        conn.close()
    logger.info(f"Stato pipeline registrato: {status} (fonti ok={sources_ok}, fonti in errore={sources_failed}, "
                f"estratti={extracted}, scartati={rejected}, inseriti={inserted}, aggiornati={updated})")
