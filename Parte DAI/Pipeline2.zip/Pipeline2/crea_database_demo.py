"""Crea 6 database sorgente DEMO (uno per struttura) a partire dai CSV di Buby Travel,
per provare la pipeline multi-database senza avere i gestionali reali.

Ogni database contiene:
  - le tabelle della propria struttura: struttura, camere, listino, prenotazioni, occupazione_giornaliera
  - una copia delle tabelle condivise: canali, stagionalita, eventi, promozioni
Le colonne sono tutte TEXT, con i dati "sporchi" originali: la pulizia la fa la pipeline.

Uso (PowerShell), basta una sola variabile:
  $env:DATABASE_URL="postgresql://postgres:PASSWORD@localhost:5432/buby_travel"
  python crea_database_demo.py C:\\percorso\\cartella_csv
  python flow.py
I 6 database demo vengono creati sullo stesso server di DATABASE_URL e la pipeline li trova da sola.
"""
import csv
import difflib
import os
import re
import sys

import psycopg2
from psycopg2.extras import execute_values

from config import DATABASE_URL, SOURCE_DATABASES, SOURCE_TABLES, STRUTTURE_ALIASES, check_url, same_server_url

# Connessione di amministrazione: di default lo stesso server di DATABASE_URL, database "postgres"
ADMIN_URL = os.getenv("ADMIN_URL") or same_server_url("postgres")
CSV_DIR = sys.argv[1] if len(sys.argv) > 1 else "data"

FILES = {  # tabella logica -> file CSV
    "strutture": "strutture.csv", "camere": "camere.csv", "canali": "canali.csv",
    "stagionalita": "stagionalita.csv", "eventi": "eventi.csv", "listino": "listino.csv",
    "promozioni": "promozioni.csv", "prenotazioni": "prenotazioni.csv",
    "occupazione": "occupazione_giornaliera.csv",
}
SHARED = ["canali", "stagionalita", "eventi", "promozioni"]


def key(v):
    return re.sub(r"[\s_\-./&]+", "", str(v)).lower()


def read_csv(name):
    with open(os.path.join(CSV_DIR, FILES[name]), encoding="utf-8", newline="") as f:
        rows = list(csv.reader(f))
    return rows[0], rows[1:]


def db_url(dbname):
    return ADMIN_URL.rsplit("/", 1)[0] + "/" + dbname


def main():
    data = {n: read_csv(n) for n in FILES}

    # nome struttura (in tutte le sue scritture) -> id
    h, rows = data["strutture"]
    i_id, i_nome = h.index("id_struttura"), h.index("nome")
    names = {}
    for r in rows:
        names[key(r[i_nome])] = r[i_id]
        names[key(re.sub(r"^(hotel|residence|chalet)\s+", "", r[i_nome], flags=re.I))] = r[i_id]
    names.update({key(a): sid for a, sid in STRUTTURE_ALIASES.items()})

    def sid_of(nome):
        k = key(nome)
        if k in names:
            return names[k]
        m = difflib.get_close_matches(k, list(names), n=1, cutoff=0.8)
        return names[m[0]] if m else None

    check_url(ADMIN_URL, "DATABASE_URL")
    admin = psycopg2.connect(ADMIN_URL)
    admin.autocommit = True
    # crea anche il database di destinazione, se non esiste ancora
    target = DATABASE_URL.rsplit("/", 1)[1]
    with admin.cursor() as cur:
        cur.execute("SELECT 1 FROM pg_database WHERE datname = %s", (target,))
        if not cur.fetchall():
            cur.execute(f'CREATE DATABASE "{target}"')
            print(f"Creato il database di destinazione '{target}'.")
    for src in SOURCE_DATABASES:
        dbname = src["url"].rsplit("/", 1)[1]
        sid = src["id_struttura"]
        with admin.cursor() as cur:
            cur.execute(f'DROP DATABASE IF EXISTS "{dbname}"')
            cur.execute(f'CREATE DATABASE "{dbname}"')

        conn = psycopg2.connect(same_server_url(dbname))
        with conn, conn.cursor() as cur:
            for name, (header, rows) in data.items():
                if name in SHARED:
                    sel = rows
                elif name in ("strutture", "camere", "listino"):
                    i = header.index("id_struttura")
                    sel = [r for r in rows if r[i].strip().upper() == sid]
                else:   # prenotazioni / occupazione: per nome struttura
                    i = header.index("struttura")
                    sel = [r for r in rows if sid_of(r[i]) == sid]
                table = SOURCE_TABLES[name]
                cols = ", ".join(f'"{c}" TEXT' for c in header)
                cur.execute(f"CREATE TABLE {src['schema']}.{table} ({cols})")
                if sel:
                    execute_values(cur, f"INSERT INTO {src['schema']}.{table} VALUES %s",
                                   [[v if v != "" else None for v in r] for r in sel], page_size=2000)
                print(f"{dbname}.{table}: {len(sel)} righe")
        conn.close()
    admin.close()
    print("Database demo creati.")


if __name__ == "__main__":
    main()
