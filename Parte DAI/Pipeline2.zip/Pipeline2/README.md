# Pipeline ETL Buby Travel: 6 database → PostgreSQL unico

Pipeline Prefect che **estrae** i dati da 6 database sorgente (uno per struttura), li **unisce**,
li **pulisce** e li carica in un **unico database PostgreSQL**, come tabelle collegate da chiavi esterne.

```
 db_riva_del_lago (S01) ─┐
 db_belvedere     (S02) ─┤
 db_le_palme      (S03) ─┤  estrazione → unione → pulizia → quarantena → validazione → buby_travel_dw
 db_cime_bianche  (S04) ─┤                                     │
 db_chalet_alpino (S05) ─┤                                     └→ scarti (con la fonte di provenienza)
 db_monte_rosa    (S06) ─┘
```

## Avvio (PowerShell)

```powershell
pip install -r requirements.txt
# destinazione (il database deve esistere; lo schema buby_travel_dw viene creato dalla pipeline)
$env:DATABASE_URL="postgresql://postgres:PASSWORD@localhost:5432/buby_travel"
# sorgenti: una variabile per struttura
$env:DB_URL_S01="postgresql://utente:password@host-s01:5432/hotel_riva_del_lago"
$env:DB_URL_S02="postgresql://utente:password@host-s02:5432/hotel_belvedere"
$env:DB_URL_S03="postgresql://utente:password@host-s03:5432/residence_le_palme"
$env:DB_URL_S04="postgresql://utente:password@host-s04:5432/hotel_cime_bianche"
$env:DB_URL_S05="postgresql://utente:password@host-s05:5432/chalet_alpino"
$env:DB_URL_S06="postgresql://utente:password@host-s06:5432/hotel_monte_rosa"
python flow.py
```

Le sorgenti PostgreSQL si leggono con psycopg2. Per altri motori (MySQL, SQL Server…) basta un URL
SQLAlchemy (es. `mysql+pymysql://...`) dopo `pip install sqlalchemy` più il driver del motore.

### Provare senza i database reali

`crea_database_demo.py` crea i 6 database sorgente a partire dai CSV, divisi per struttura e con i
dati "sporchi" originali, sullo stesso server di `DATABASE_URL`. Basta una sola variabile:

```powershell
$env:DATABASE_URL="postgresql://postgres:PASSWORD@localhost:5432/buby_travel"
python crea_database_demo.py C:\percorso\cartella_csv
python flow.py
```

Se una `DB_URL_S0x` non è impostata, la pipeline usa lo stesso server e le stesse credenziali di
`DATABASE_URL` con il nome del database della fonte.

## Configurazione delle fonti (config.py → `SOURCE_DATABASES`)

Ogni fonte dichiara nome, struttura, URL e schema. Se il gestionale di una struttura usa nomi
diversi, si mappano senza toccare il codice:

```python
_src("db_monte_rosa", "S06", "hotel_monte_rosa",
     tabelle={"prenotazioni": "bookings", "recensioni": None},             # None = tabella assente
     colonne={"prenotazioni": {"booking_code": "id_prenotazione"}})
```

Al posto del nome di una tabella si può scrivere anche una query `SELECT ...` completa.

## Unione dei dati

| Tipo di tabella | Tabelle | Come si uniscono |
|---|---|---|
| **Per struttura** | strutture, camere, listino, prenotazioni, occupazione, recensioni | UNION di tutte le fonti; ogni record riceve la colonna `fonte` |
| **Condivise** | canali, stagionalità, eventi, promozioni | Ogni fonte ne ha una copia: le copie identiche si unificano. Se le versioni differiscono, si tiene quella presente nel maggior numero di fonti e le altre vanno in `scarti` (`versione_diversa_tra_fonti_scartata`) |

- **Id univoci nel database unico**: gli id di prenotazioni e recensioni sono univoci solo dentro
  il proprio database, quindi si prefissano con la struttura (`BT24-00001` → `S01-BT24-00001`).
  L'id originale resta in `id_prenotazione_origine` / `id_recensione_origine`.
- **Coerenza fonte–struttura**: se un record non indica la struttura, si assegna quella del suo
  database; se ne indica un'altra, va in quarantena (`struttura_diversa_da_quella_della_fonte`).
- **Fonte irraggiungibile**: con `SOURCE_ERROR_POLICY=skip` (predefinito) la fonte viene saltata,
  le altre si caricano e l'esecuzione risulta `PARTIAL` in `pipeline_runs`. Con `fail` la pipeline
  si ferma. `MIN_SOURCES_OK` fissa il numero minimo di fonti lette.
- **Rilanci**: la pipeline fa *upsert*. Quando una fonte torna disponibile, i suoi dati si
  aggiungono senza duplicare quelli già caricati.

## Fasi (flow.py)

| # | Task | Cosa fa |
|---|------|---------|
| 1 | `extract_sources` | Si collega a ogni database e legge le tabelle come testo; aggiunge fonte e prefissi agli id |
| 2 | `merge_sources` | Unisce le tabelle delle 6 fonti |
| 3 | `profile_data` | Nulli, duplicati, varianti delle categoriche, formati di date e importi, statistiche |
| 4 | `standardize_formats` | Date → `AAAA-MM-GG`; importi → numero a 2 decimali in €; ospiti → adulti/bambini/neonati/totale; voti → 0-10; aperture → `MM-GG` |
| 5 | `clean_categoricals` | Spazi, maiuscole, alias e refusi → valore canonico; struttura coerente con la fonte |
| 6 | `handle_missing_values` | Strategia per colonna (vedi sotto) |
| 7 | `handle_numeric_outliers` | Limiti rigidi → quarantena; outlier IQR (k=3) → solo flag `is_outlier_*` |
| 8 | `check_business_rules` | Una sola versione delle tabelle condivise; regole bloccanti e non bloccanti |
| 9 | `quarantine_rejected` | Scarti in `scarti` con fonte, motivo e record originale; controllo delle FK |
| 10 | `validate_data` | Chiavi primarie ed esterne, campi obbligatori, domini |
| 11 | `load_data` | Upsert in un'unica transazione, nell'ordine delle FK |
| 12 | `log_execution` | Riepilogo in `pipeline_runs` (SUCCESS / PARTIAL / ERROR, con fonti ok/in errore) |

## Schema (chiavi esterne)

```
aree ─┬─< strutture ─┬─< periodi_apertura
      │              ├─< camere ─┬─< listino >── stagionalita >── aree
      │              │           └─< prenotazioni >── canali, promozioni, trattamenti, paesi
      │              └─< occupazione_giornaliera
      │   prenotazioni ─< recensioni   (viste: v_recensioni, v_riepilogo_fonti)
      ├─< stagionalita
      └─< eventi
promozioni ─< promozioni_canali >─ canali
```

## Formati unici

- **Date**: tipo `DATE` (`AAAA-MM-GG`). Nei file c'erano 4 formati: `AAAA-MM-GG hh:mm:ss`,
  `AAAA-MM-GG`, `GG/MM/AAAA`, `GG-MM-AA`. Date di validità rinominate ovunque `data_inizio` / `data_fine`.
- **Importi**: `NUMERIC(10,2)` in euro, colonne con suffisso `_eur` (`€ 1.131,10`, `965,64`, `1111 EUR` → `1131.10` …).
- **Percentuali**: `NUMERIC(5,2)` da 0 a 100, suffisso `_pct`.
- **Ospiti**: 183 scritture diverse (`2A+1B`, `2 ad. 1 bamb.`, `2 adulti, 2 bambini (9 e 8 anni)` …) →
  `adulti`, `bambini`, `neonati` (età < 2), `totale_ospiti`, `eta_bambini` (array, se note).
- **Periodi di apertura**: tabella `periodi_apertura` con `inizio_mm_gg` / `fine_mm_gg` (es. `03-01` → `11-15`).
- **Struttura**: nelle tabelle operative si usa solo `id_struttura` (19 scritture del nome → 6 id).

## Valori mancanti

| Colonna | Scelta |
|---|---|
| campi critici (date, struttura, importo, stato…) | quarantena |
| `codice_paese` | `XX` (sconosciuto, codice ISO riservato) |
| `codice_promo`, `note`, `data_cancellazione` | NULL: l'assenza è un'informazione vera |
| supplementi pensione dei residence | NULL: non previsti (niente ristorante) |
| supplementi pensione degli hotel | quarantena |
| `ospiti_presenti` (occupazione) | stima = camere occupate × ospiti medi per camera della struttura, marcata con `ospiti_presenti_stimati = TRUE` |
| arrivi, partenze, camere fuori servizio | 0 |

## Regole di business

**Bloccanti (quarantena)**: 0 ospiti; nessun adulto; check-out non successivo al check-in;
prenotazione successiva al check-in; stato confermata/no-show con data di cancellazione;
cancellazione prima della prenotazione; stesso id con dati diversi; struttura/tipologia/canale
non riconosciuti o inesistenti; camere occupate oltre le disponibili; date o importi illeggibili;
valori fuori dai limiti fisici (`HARD_LIMITS` in config.py).

**Non bloccanti (flag in `dq_flags`)**: notti ricalcolate dalle date; check-in/check-out invertiti
(corretti); cancellata senza data; ospiti oltre la capienza della camera; soggiorno in periodo di
chiusura; promo su canale non ammesso o senza i requisiti (EARLY60, LASTMIN, SKI3); importo 0 su
confermata; tariffa non coerente con la stagione; listino senza calendario stagionalità.

## Recensioni (tabella facoltativa in ogni fonte)

Se un database sorgente ha la tabella `recensioni`, questa viene caricata e collegata a
`prenotazioni`; se non ce l'ha, per quella fonte non risultano recensioni.

Colonne: `id_recensione, id_prenotazione, data_recensione, voto, piattaforma, titolo, testo`
(accettati anche nomi alternativi come `rating`, `punteggio`, `commento`, `review_text`, `fonte`).

- **Voto in formato unico** `voto_10` (0-10, un decimale): `4/5` → 8.0, `8,5/10` → 8.5, `85%` → 8.5,
  `★★★★☆` → 8.0. Un numero senza scala viene interpretato (≤5 su 5, ≤10 su 10) e marcato con flag.
  Il valore originale resta in `voto_originale`.
- **Mancanti**: piattaforma → `Non indicata`; voto o testo possono mancare (non entrambi).
- **Privacy**: email e numeri di telefono nel testo vengono sostituiti con `[email]` / `[telefono]`.
- **Bloccanti**: prenotazione inesistente, cancellata o no-show; recensione prima del check-in o con
  data futura; voto illeggibile o oltre la scala; né voto né testo; stesso id con dati diversi.
- **Flag**: scritta durante il soggiorno; oltre 365 giorni dal check-out; più recensioni per la
  stessa prenotazione e piattaforma; testo sotto le 3 parole; piattaforma sconosciuta (→ `Altro`).

## Esito sui 6 database demo

Lette 17.794 righe dalle 6 fonti, incluse le 6 copie delle tabelle condivise (le copie identiche
unificate sono 405). Caricate 17.403 righe: 13.882 prenotazioni, 2.778 giorni di occupazione e
591 righe di listino. In quarantena 6 giorni di occupazione con più camere occupate che
disponibili; rimosse 26 prenotazioni duplicate identiche. Il risultato è identico a quello
ottenuto dai file singoli.

## Query utili

```sql
-- scarti e motivi
SELECT tabella, fonte, motivo, count(*) FROM buby_travel_dw.scarti GROUP BY 1, 2, 3;
-- quante prenotazioni per fonte
SELECT * FROM buby_travel_dw.v_riepilogo_fonti;
-- record caricati ma con anomalie
SELECT unnest(string_to_array(dq_flags, ';')) AS flag, count(*)
FROM buby_travel_dw.prenotazioni GROUP BY 1 ORDER BY 2 DESC;
-- ultime esecuzioni
SELECT status, sources_ok, sources_failed, errors FROM buby_travel_dw.pipeline_runs ORDER BY ts DESC LIMIT 5;
```
