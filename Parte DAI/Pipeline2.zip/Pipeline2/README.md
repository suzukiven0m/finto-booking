# Pipeline ETL Buby Travel → PostgreSQL

Pipeline Prefect che pulisce i 9 file CSV di Buby Travel (uno per foglio dei 4 Excel originali) e li carica su PostgreSQL
come **tabelle separate collegate da chiavi esterne** (i file non vengono uniti).

## Avvio

### 0. Prerequisiti

- **Python 3.10+** (testato con 3.12 e 3.14)
- **PostgreSQL** installato e **in esecuzione** (qualsiasi versione recente; porta di default `5432`)
- I 9 file CSV nella cartella `data/` accanto agli script

### 1. Installa le dipendenze

```bash
pip install -r requirements.txt
```

### 2. Scegli utente e password del database

La pipeline si collega a PostgreSQL con queste credenziali. **Vanno scritte in `config.py` (righe in alto)**
oppure passate con la variabile d'ambiente `DATABASE_URL`:

| Parametro in `config.py` | Valore da usare |
|---|---|
| **`DB_USER`** | **`postgres`** (o l'utente che hai creato tu) |
| **`DB_PASSWORD`** | **la password scelta durante l'installazione di PostgreSQL** |
| `DB_HOST` | `127.0.0.1` |
| `DB_PORT` | `5432` (cambiala se PostgreSQL usa un'altra porta, es. `5433`) |
| `DB_NAME` | `buby_travel` |

```python
# config.py
DB_USER = "postgres"
DB_PASSWORD = "LA_TUA_PASSWORD"
```

> **Attenzione:** se la password contiene caratteri speciali vanno codificati: `@` → `%40`, `#` → `%23`, `/` → `%2F`, `:` → `%3A`, `%` → `%25`.
> Non pubblicare mai `config.py` con la password reale (es. su GitHub).

In alternativa, senza toccare il codice, la variabile d'ambiente ha la precedenza su `config.py`:

```powershell
# Windows (PowerShell) - vale solo per la finestra in cui la scrivi
$env:DATABASE_URL = "postgresql://postgres:LA_TUA_PASSWORD@127.0.0.1:5432/buby_travel"
```
```bash
# Linux / macOS
export DATABASE_URL="postgresql://postgres:LA_TUA_PASSWORD@127.0.0.1:5432/buby_travel"
```

### 3. Crea il database (una sola volta)

Il database **deve esistere prima** di lanciare la pipeline; schema e tabelle le crea la pipeline.
Il percorso di `psql` dipende dal computer: sostituisci `<VERSIONE>` con la versione di PostgreSQL installata
(es. `16`, `17`, `19`). Chiederà la password dell'utente `postgres`.

**Windows (PowerShell)**

```powershell
& "C:\Program Files\PostgreSQL\<VERSIONE>\bin\psql.exe" -U postgres -c "CREATE DATABASE buby_travel;"
```

Non sai la versione? Trova `psql.exe` con:

```powershell
Get-ChildItem "C:\Program Files\PostgreSQL" -Recurse -Filter psql.exe -ErrorAction SilentlyContinue | Select-Object FullName
```

Oppure aggiungi la cartella `bin` al PATH solo per la sessione corrente e usa `psql` direttamente:

```powershell
$env:Path += ";C:\Program Files\PostgreSQL\<VERSIONE>\bin"
psql -U postgres -c "CREATE DATABASE buby_travel;"
```

**Linux**

```bash
sudo -u postgres psql -c "CREATE DATABASE buby_travel;"
```

**macOS (Homebrew)**

```bash
psql -U postgres -c "CREATE DATABASE buby_travel;"
```

**Con Docker (nessuna installazione di PostgreSQL)**

```bash
docker run -d --name pg -e POSTGRES_PASSWORD=LA_TUA_PASSWORD -e POSTGRES_DB=buby_travel -p 5432:5432 postgres:17
```

Con Docker il database `buby_travel` viene creato in automatico e **`DB_USER` = `postgres`**.

Alternativa grafica: in **pgAdmin** → tasto destro su *Databases* → *Create* → *Database…* → nome `buby_travel`.

### 4. Verifica che PostgreSQL sia acceso

```powershell
# Windows: il nome del servizio contiene la versione, es. postgresql-x64-17
Get-Service *postgres*
Start-Service postgresql-x64-<VERSIONE>      # da PowerShell come amministratore
Test-NetConnection 127.0.0.1 -Port 5432      # TcpTestSucceeded deve essere True
```
```bash
# Linux
sudo systemctl status postgresql
sudo systemctl start postgresql
```

### 5. Avvia la pipeline

Dalla cartella del progetto:

```bash
python flow.py
```

Se tutto va bene le ultime righe del log sono:

```
[INFO] ... - Stato pipeline registrato: SUCCESS (estratti=17389, scartati=6, ...)
... Flow run '...' - Finished in state Completed()
```

Opzioni (variabili d'ambiente, tutte facoltative): `DATA_DIR` (cartella dei CSV, default: `data/` accanto agli script),
`DB_SCHEMA` (default `buby_travel`), `CSV_ENCODING` (default `utf-8`), `CSV_SEPARATOR` (default `,`, es. `;`).

File attesi in `DATA_DIR`: `strutture.csv`, `camere.csv`, `canali.csv`, `stagionalita.csv`,
`eventi.csv`, `listino.csv`, `promozioni.csv`, `prenotazioni.csv`, `occupazione_giornaliera.csv`.
Rilanciare la pipeline è sicuro: fa *upsert*, non duplica.

## Fasi (flow.py)

| # | Task | Cosa fa |
|---|------|---------|
| 1 | `extract_data` | Legge ogni CSV come testo, toglie spazi extra, righe vuote e note a piè di pagina |
| 2 | `profile_data` | Nulli, duplicati, varianti delle categoriche, formati di date/importi, statistiche |
| 3 | `standardize_formats` | Date → `AAAA-MM-GG`; importi → numero a 2 decimali in €; ospiti → adulti/bambini/neonati/totale; aperture → `MM-GG` |
| 4 | `clean_categoricals` | Spazi, maiuscole, alias, refusi → valore canonico (strutture → `id_struttura`, paesi → ISO a 2 lettere) |
| 5 | `handle_missing_values` | Strategia per colonna (vedi sotto) |
| 6 | `handle_numeric_outliers` | Limiti rigidi → quarantena; outlier IQR (k=3) → solo flag `is_outlier_*` |
| 7 | `check_business_rules` | Regole bloccanti (quarantena) e non bloccanti (flag in `dq_flags`) |
| 8 | `quarantine_rejected` | Scarti nella tabella `scarti` con motivo e record originale; controllo FK |
| 9 | `validate_data` | Chiavi primarie/esterne, campi obbligatori, domini |
| 10 | `load_data` | Upsert in un'unica transazione, nell'ordine delle FK |
| 11 | `log_execution` | Riepilogo in `pipeline_runs`; ogni log anche in `pipeline_logs` |

## Schema (chiavi esterne)

```
aree ─┬─< strutture ─┬─< periodi_apertura
      │              ├─< camere ─┬─< listino >── stagionalita >── aree
      │              │           └─< prenotazioni >── canali, promozioni, trattamenti, paesi
      │              └─< occupazione_giornaliera
      ├─< stagionalita
      └─< eventi
promozioni ─< promozioni_canali >─ canali
```

## Formati unici

- **Date**: tipo `DATE` (`AAAA-MM-GG`). Nei file c'erano 4 formati: `AAAA-MM-GG hh:mm:ss`,
  `AAAA-MM-GG`, `GG/MM/AAAA`, `GG-MM-AA`. Date di validità rinominate ovunque `data_inizio` / `data_fine`.
- **Importi**: `NUMERIC(10,2)` in euro, colonne con suffisso `_eur` (`€ 1.131,10`, `965,64`, `1111 EUR` → `1131.10` …).
- **Percentuali**: `NUMERIC(5,2)` da 0 a 100, suffisso `_pct`.
- **Ospiti**: 183 scritture diverse (`2A+1B`, `2 ad. 1 bamb.`, `2 adulti, 2 bambini (9 e 8 anni)` …) →
  `adulti`, `bambini`, `neonati` (età < 2), `totale_ospiti`, `eta_bambini` (array, se note).
- **Periodi di apertura**: tabella `periodi_apertura` con `inizio_mm_gg` / `fine_mm_gg` (es. `03-01` → `11-15`).
- **Struttura**: nelle tabelle operative si usa solo `id_struttura` (19 scritture del nome → 6 id).

## Valori mancanti

| Colonna | Scelta |
|---|---|
| campi critici (date, struttura, importo, stato…) | quarantena |
| `codice_paese` | `XX` (sconosciuto, codice ISO riservato) |
| `codice_promo`, `note`, `data_cancellazione` | NULL: l'assenza è un'informazione vera |
| supplementi pensione dei residence | NULL: non previsti (niente ristorante) |
| supplementi pensione degli hotel | quarantena |
| `ospiti_presenti` (occupazione) | stima = camere occupate × ospiti medi per camera della struttura, marcata con `ospiti_presenti_stimati = TRUE` |
| arrivi, partenze, camere fuori servizio | 0 |

## Regole di business

**Bloccanti (quarantena)**: 0 ospiti; nessun adulto; check-out non successivo al check-in;
prenotazione successiva al check-in; stato confermata/no-show con data di cancellazione;
cancellazione prima della prenotazione; stesso id con dati diversi; struttura/tipologia/canale
non riconosciuti o inesistenti; camere occupate oltre le disponibili; date o importi illeggibili;
valori fuori dai limiti fisici (`HARD_LIMITS` in config.py).

**Non bloccanti (flag in `dq_flags`)**: notti ricalcolate dalle date; check-in/check-out invertiti
(corretti); cancellata senza data; ospiti oltre la capienza della camera; soggiorno in periodo di
chiusura; promo su canale non ammesso o senza i requisiti (EARLY60, LASTMIN, SKI3); importo 0 su
confermata; tariffa non coerente con la stagione; listino senza calendario stagionalità.

## Esito sui file attuali

17.389 record letti → 17.403 righe caricate (incluse le tabelle di dominio), 6 in quarantena
(giorni di occupazione con più camere occupate che disponibili), 26 prenotazioni duplicate
identiche rimosse. Principali flag: 215 notti ricalcolate, 9 date invertite corrette,
50 confermate con importo 0, 106 righe di listino 2027 senza calendario stagionalità.

## Risoluzione dei problemi

La pipeline pulisce i dati prima di toccare il database: se vedi nel log tutti i task `Completed()` fino a
`validate_data` e l'errore compare in `load_data`, il problema è **sempre** la connessione a PostgreSQL.

| Errore nel log | Causa | Soluzione |
|---|---|---|
| `connection to server at "localhost" ... port 5432 failed: Connection refused` | PostgreSQL non è in esecuzione, oppure è su un'altra porta | Avvia il servizio (punto 4). Controlla la porta in `postgresql.conf` e aggiorna **`DB_PORT`** |
| `autenticazione con password fallita per l'utente "<username>"` (o `password authentication failed`) | **`DB_USER`** / **`DB_PASSWORD`** non impostati (restano i segnaposto) o errati. La variabile `DATABASE_URL` vale solo nella finestra di terminale in cui è stata scritta: con il tasto *Run* di VS Code lo script parte in un altro terminale | Scrivi **`DB_USER`** e **`DB_PASSWORD`** in `config.py` (punto 2) |
| `Password di PostgreSQL non impostata` | `DB_PASSWORD` è ancora `INSERISCI_LA_PASSWORD` | Sostituiscila con la tua password in `config.py` |
| `database "buby_travel" does not exist` | Il database non è stato creato | Esegui il comando del punto 3 |
| `Impossibile avviare il servizio postgresql-x64-NN` | Permessi, file `postmaster.pid` residuo o porta occupata | Avvia PowerShell **come amministratore**. Leggi l'ultimo file in `C:\Program Files\PostgreSQL\<VERSIONE>\data\log`: se c'è `lock file "postmaster.pid" already exists` elimina `data\postmaster.pid`; se c'è `Address already in use` cambia porta |
| `'psql' non riconosciuto come nome di cmdlet` (Windows) | La cartella `bin` di PostgreSQL non è nel PATH | Usa il percorso completo `& "C:\Program Files\PostgreSQL\<VERSIONE>\bin\psql.exe" ...` (punto 3) |
| `FileNotFoundError ... data\xxx.csv` | CSV mancanti o cartella dati diversa | Metti i 9 CSV in `data/` accanto a `flow.py`, oppure imposta `DATA_DIR` |
| `UnicodeDecodeError` / caratteri strani (`Ã¨`) | CSV esportati da Excel in codifica diversa | `CSV_ENCODING=cp1252` (o `utf-8-sig`) |
| Tutte le colonne in una sola (`a;b;c`) | Separatore `;` | `CSV_SEPARATOR=";"` |
| `ModuleNotFoundError: No module named 'prefect'` (o `psycopg2`, `pandas`) | Dipendenze non installate | `pip install -r requirements.txt` |
| `Logging error` / `[WARN] Log su PostgreSQL disattivato` | Il log su tabella `pipeline_logs` non riesce a connettersi: è solo un avviso, la pipeline continua e scrive su console | Risolvi la connessione (righe sopra) |

Il tentativo di scrittura del log di errore su `pipeline_runs` fallisce a sua volta se il database non è
raggiungibile: è normale, la causa originale è la prima riga di errore del log.

## Query utili

```sql
-- scarti e motivi
SELECT tabella, motivo, count(*) FROM buby_travel.scarti GROUP BY 1, 2;
-- record caricati ma con anomalie
SELECT unnest(string_to_array(dq_flags, ';')) AS flag, count(*)
FROM buby_travel.prenotazioni GROUP BY 1 ORDER BY 2 DESC;
-- ultime esecuzioni
SELECT * FROM buby_travel.pipeline_runs ORDER BY ts DESC LIMIT 5;
```
